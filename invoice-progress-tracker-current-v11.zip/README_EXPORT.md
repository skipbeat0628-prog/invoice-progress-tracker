# 發票進度追蹤 — 可遷移原始碼匯出

此封包為 Sites 專案目前已儲存的第 11 版原始碼快照，來源 commit：
`60ed64d8978b3f19af07cd95d5e7bbdcc0ba5d6b`。

## 內容

- `app/`：前端頁面與 API routes
- `worker/`：Cloudflare Worker 入口
- `db/`、`drizzle/`：資料庫 schema 與 migration
- `.openai/hosting.json`：Sites 邏輯資源綁定設定
- `package.json`、`pnpm-lock.yaml`：依賴與鎖定版本
- 其餘建置、TypeScript、CSS 與靜態資源

## 執行環境綁定

此版本不需要一般文字型環境變數，也沒有附帶任何 Secret。部署環境需提供：

- `DB`：Cloudflare D1 database binding（邏輯名稱記錄於 `.openai/hosting.json`）
- `ASSETS`：由 Sites／Cloudflare 建置流程提供的靜態資源 binding
- `IMAGES`：由 Sites／Cloudflare 建置流程提供的影像轉換 binding

上述是平台資源綁定，不應填入 `.env`。若移植到其他平台，需為它們建立等效服務或調整 adapter。

## 安全與資料範圍

- 封包不含 OAuth token、API key、密碼、Secret 或短期原始碼存取憑證。
- 封包只包含原始碼與資料庫結構，不包含線上 D1 資料庫中的客戶紀錄。
- 建立此封包未修改或重新部署站點，也未改動線上資料。
