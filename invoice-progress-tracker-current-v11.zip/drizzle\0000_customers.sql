CREATE TABLE IF NOT EXISTS `customers` (
  `id` text PRIMARY KEY NOT NULL,
  `code` text NOT NULL,
  `title` text NOT NULL,
  `owner` text DEFAULT '' NOT NULL,
  `registered_date` text DEFAULT '' NOT NULL,
  `sorted` integer DEFAULT false NOT NULL,
  `keyed` integer DEFAULT false NOT NULL,
  `uploaded` integer DEFAULT false NOT NULL,
  `updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS `idx_customers_code` ON `customers` (`code`);
