"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import {
  CalendarDays, Check, ChevronDown, Circle, CircleCheck, Clock3, Download,
  FileSpreadsheet, Filter, Info, Plus, Search, Trash2, Upload, Users, X,
} from "lucide-react";
import * as XLSX from "xlsx";

type Customer = {
  id: string; code: string; title: string; owner: string; registeredDate: string;
  sort: Step; keyin: Step; check: Step; upload: Step; updatedAt: string;
};
type Step = { done: boolean; handler: string | null };
type StepKey = "sort" | "keyin" | "check" | "upload";
const HANDLERS = ["小玉", "Grace", "蕙琪", "玲玲", "俐蓉"];
const STEP_LABELS: Record<StepKey, string> = { sort: "整理", keyin: "Key in", check: "檢查", upload: "上傳" };

const STORAGE_KEY = "invoice-progress-customers-v1";
const ALL_OWNERS = "全部負責人";
const ALL_STAGES = "全部階段";
const ALL_CODE_GROUPS = "全部客編";
const CODE_GROUPS = ["A0", "A1", "A2", "A3", "A4", "A5", "所有 O", "LA／LC", "其他"];
const CODE_HEADERS = ["客編", "客戶編號", "客戶代號", "編號"];
const TITLE_HEADERS = ["抬頭", "客戶名稱", "公司名稱"];

const today = () => {
  const date = new Date();
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};
const textValue = (value: unknown) => String(value ?? "").trim();
const findValue = (row: Record<string, unknown>, headers: string[]) => {
  for (const header of headers) if (header in row) return row[header];
  return undefined;
};
const truthyExcel = (value: unknown) => ["1", "true", "yes", "y", "是", "完成", "v", "✓", "✔"].includes(textValue(value).toLowerCase());
const excelDate = (value: unknown) => {
  if (typeof value === "number") {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed) return `${parsed.y}-${String(parsed.m).padStart(2, "0")}-${String(parsed.d).padStart(2, "0")}`;
  }
  const match = textValue(value).replaceAll("/", "-").match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  return match ? `${match[1]}-${match[2].padStart(2, "0")}-${match[3].padStart(2, "0")}` : "";
};
const normalizeStep = (value: unknown): Step => typeof value === "boolean"
  ? { done: value, handler: null }
  : { done: Boolean((value as Step | undefined)?.done), handler: (value as Step | undefined)?.handler || null };
const normalizeCustomer = (value: Record<string, unknown>): Customer => ({
  ...value,
  sort: normalizeStep(value.sort ?? value.sorted), keyin: normalizeStep(value.keyin ?? value.keyed),
  check: normalizeStep(value.check ?? value.checked), upload: normalizeStep(value.upload ?? value.uploaded),
}) as Customer;
const stage = (customer: Customer) => customer.upload.done ? "已完成" : customer.check.done ? "待上傳" : customer.keyin.done ? "待檢查" : customer.sort.done ? "Key in 中" : "待整理";
const codeGroup = (code: string) => {
  const normalized = code.trim().toUpperCase();
  for (const prefix of ["A0", "A1", "A2", "A3", "A4", "A5"]) if (normalized.startsWith(prefix)) return prefix;
  if (normalized.startsWith("O")) return "所有 O";
  if (normalized.startsWith("LA") || normalized.startsWith("LC")) return "LA／LC";
  return "其他";
};
const displayDate = (value: string) => value ? value.replaceAll("-", "/") : "—";
const sortByCode = (a: Customer, b: Customer) => a.code.localeCompare(b.code, "zh-TW", { numeric: true, sensitivity: "base" });
const exportRow = (item: Customer) => ({
  客編: item.code, 抬頭: item.title, 負責人: item.owner, 登記日期: displayDate(item.registeredDate),
  整理: item.sort.done ? "完成" : "未完成", 整理經手人: item.sort.handler || "",
  "Key in": item.keyin.done ? "完成" : "未完成", "Key in 經手人": item.keyin.handler || "",
  檢查: item.check.done ? "完成" : "未完成", 檢查經手人: item.check.handler || "",
  上傳: item.upload.done ? "完成" : "未完成", 上傳經手人: item.upload.handler || "",
  目前階段: stage(item), 最後更新時間: new Date(item.updatedAt).toLocaleString("zh-TW"),
});

export function parseImportedRows(rows: Record<string, unknown>[]): Customer[] {
  if (!rows.length) throw new Error("empty");
  const headers = Object.keys(rows[0]);
  if (!CODE_HEADERS.some((key) => headers.includes(key)) || !TITLE_HEADERS.some((key) => headers.includes(key))) {
    throw new Error("missing-required-columns");
  }
  const now = new Date().toISOString();
  return rows.map((row, index) => ({
    id: `${Date.now()}-${index}`,
    code: textValue(findValue(row, CODE_HEADERS)),
    title: textValue(findValue(row, TITLE_HEADERS)),
    owner: textValue(row["負責人"]),
    registeredDate: excelDate(row["登記日期"] ?? row["日期"]),
    sort: { done: truthyExcel(row["整理"]), handler: textValue(row["整理經手人"]) || null },
    keyin: { done: truthyExcel(row["Key in"] ?? row["Key In"]), handler: textValue(row["Key in 經手人"]) || null },
    check: { done: truthyExcel(row["檢查"]), handler: textValue(row["檢查經手人"]) || null },
    upload: { done: truthyExcel(row["上傳"]), handler: textValue(row["上傳經手人"]) || null },
    updatedAt: now,
  })).filter((customer) => customer.code && customer.title);
}

export function parseImportedSheet(matrix: unknown[][]): Customer[] {
  if (!matrix.length) throw new Error("empty");
  const headerRowIndex = matrix.findIndex((row) => row.some((cell) => CODE_HEADERS.includes(textValue(cell))) && row.some((cell) => TITLE_HEADERS.includes(textValue(cell))));
  if (headerRowIndex < 0) throw new Error("missing-required-columns");
  const headers = matrix[headerRowIndex].map(textValue);
  const codeColumns = headers.map((header, index) => CODE_HEADERS.includes(header) ? index : -1).filter((index) => index >= 0);
  const groups = codeColumns.map((codeColumn, groupIndex) => {
    const end = codeColumns[groupIndex + 1] ?? headers.length;
    const titleColumn = headers.findIndex((header, index) => index > codeColumn && index < end && TITLE_HEADERS.includes(header));
    if (titleColumn < 0) return null;
    const findOptional = (names: string[]) => headers.findIndex((header, index) => index > codeColumn && index < end && names.includes(header));
    return { codeColumn, titleColumn, ownerColumn: findOptional(["負責人"]), dateColumn: findOptional(["登記日期", "日期"]), sortedColumn: findOptional(["整理"]), keyedColumn: findOptional(["Key in", "Key In"]), checkedColumn: findOptional(["檢查"]), uploadedColumn: findOptional(["上傳"]), sortHandlerColumn: findOptional(["整理經手人"]), keyinHandlerColumn: findOptional(["Key in 經手人"]), checkHandlerColumn: findOptional(["檢查經手人"]), uploadHandlerColumn: findOptional(["上傳經手人"]) };
  }).filter((group): group is NonNullable<typeof group> => Boolean(group));
  if (!groups.length) throw new Error("missing-required-columns");
  const now = new Date().toISOString();
  const imported: Customer[] = [];
  for (let rowIndex = headerRowIndex + 1; rowIndex < matrix.length; rowIndex++) {
    const row = matrix[rowIndex];
    for (const group of groups) {
      const code = textValue(row[group.codeColumn]);
      const title = textValue(row[group.titleColumn]);
      if (!code || !title) continue;
      imported.push({
        id: crypto.randomUUID(), code, title,
        owner: group.ownerColumn >= 0 ? textValue(row[group.ownerColumn]) : "",
        registeredDate: group.dateColumn >= 0 ? excelDate(row[group.dateColumn]) : "",
        sort: { done: group.sortedColumn >= 0 ? truthyExcel(row[group.sortedColumn]) : false, handler: group.sortHandlerColumn >= 0 ? textValue(row[group.sortHandlerColumn]) || null : null },
        keyin: { done: group.keyedColumn >= 0 ? truthyExcel(row[group.keyedColumn]) : false, handler: group.keyinHandlerColumn >= 0 ? textValue(row[group.keyinHandlerColumn]) || null : null },
        check: { done: group.checkedColumn >= 0 ? truthyExcel(row[group.checkedColumn]) : false, handler: group.checkHandlerColumn >= 0 ? textValue(row[group.checkHandlerColumn]) || null : null },
        upload: { done: group.uploadedColumn >= 0 ? truthyExcel(row[group.uploadedColumn]) : false, handler: group.uploadHandlerColumn >= 0 ? textValue(row[group.uploadHandlerColumn]) || null : null },
        updatedAt: now,
      });
    }
  }
  return Array.from(new Map(imported.map((customer) => [customer.code.toLowerCase(), customer])).values());
}

function StatCard({ label, value, tone, icon, onClick }: { label: string; value: number; tone: string; icon: React.ReactNode; onClick: () => void }) {
  return <button className="stat-card" onClick={onClick} aria-label={`查看${label}明細`}><div className={`stat-icon ${tone}`}>{icon}</div><div><p>{label}</p><strong>{value}</strong></div><span className="stat-hint">查看明細</span></button>;
}

function StepButton({ step, label, onClick }: { step: Step; label: string; onClick: () => void }) {
  return <button className={`step-button ${step.done ? "is-done" : ""}`} onClick={onClick} aria-pressed={step.done}>
    <span>{step.done ? <Check size={14} strokeWidth={3} /> : <Plus size={13} />}</span>{step.done ? `${label}．${step.handler || "未指定"}` : `＋${label}`}
  </button>;
}

export default function Home() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [search, setSearch] = useState("");
  const [owner, setOwner] = useState(ALL_OWNERS);
  const [stageFilter, setStageFilter] = useState(ALL_STAGES);
  const [codeGroupFilter, setCodeGroupFilter] = useState(ALL_CODE_GROUPS);
  const [toast, setToast] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [deleting, setDeleting] = useState<Customer | null>(null);
  const [detailStage, setDetailStage] = useState<string | null>(null);
  const [editingStep, setEditingStep] = useState<{ customer: Customer; key: StepKey } | null>(null);
  const [form, setForm] = useState({ code: "", title: "", owner: "", registeredDate: today() });
  const fileInput = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let active = true;
    const loadShared = async () => {
      try {
        const response = await fetch("/api/customers", { cache: "no-store" });
        if (!response.ok) throw new Error("load");
        let shared = (await response.json() as Record<string, unknown>[]).map(normalizeCustomer);
        if (!shared.length) {
          try {
            const local = (JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]") as Record<string, unknown>[]).map(normalizeCustomer);
            if (local.length) {
              await fetch("/api/customers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(local) });
              shared = local;
              localStorage.removeItem(STORAGE_KEY);
            }
          } catch { /* no local data to migrate */ }
        }
        if (active) { setCustomers(shared); setLoaded(true); }
      } catch { if (active) { setLoaded(true); notify("共用資料載入失敗，請重新整理再試"); } }
    };
    loadShared();
    const timer = window.setInterval(loadShared, 10000);
    return () => { active = false; window.clearInterval(timer); };
  }, []);
  const saveCustomer = async (customer: Customer) => {
    const response = await fetch("/api/customers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(customer) });
    if (!response.ok) notify("儲存失敗，請重新整理後再試");
  };

  const owners = useMemo(() => Array.from(new Set(customers.map((item) => item.owner).filter(Boolean))).sort(), [customers]);
  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    return customers.filter((item) => (!term || item.code.toLowerCase().includes(term) || item.title.toLowerCase().includes(term))
      && (owner === ALL_OWNERS || item.owner === owner) && (stageFilter === ALL_STAGES || stage(item) === stageFilter)
      && (codeGroupFilter === ALL_CODE_GROUPS || codeGroup(item.code) === codeGroupFilter)).sort(sortByCode);
  }, [customers, search, owner, stageFilter, codeGroupFilter]);
  const stats = useMemo(() => ({
    total: customers.length,
    undated: customers.filter((item) => !item.registeredDate.trim()).length,
    registered: customers.filter((item) => item.registeredDate.trim()).length,
    sorted: customers.filter((item) => item.sort.done).length,
    keyed: customers.filter((item) => item.keyin.done).length,
    checked: customers.filter((item) => item.check.done).length,
    uploaded: customers.filter((item) => item.upload.done).length,
    done: customers.filter((item) => item.sort.done && item.keyin.done && item.check.done && item.upload.done).length,
  }), [customers]);
  const detailCustomers = useMemo(() => (detailStage === "總客戶數" ? customers : detailStage === "尚未登記" ? customers.filter((item) => !item.registeredDate.trim()) : detailStage === "已登記數" ? customers.filter((item) => item.registeredDate.trim()) : detailStage === "已完成數" ? customers.filter((item) => item.sort.done && item.keyin.done && item.check.done && item.upload.done) : detailStage === "已整理" ? customers.filter((item) => item.sort.done) : detailStage === "已 Key in" ? customers.filter((item) => item.keyin.done) : detailStage === "已檢查" ? customers.filter((item) => item.check.done) : detailStage === "已上傳" ? customers.filter((item) => item.upload.done) : customers.filter((item) => stage(item) === detailStage)).slice().sort(sortByCode), [customers, detailStage]);
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(""), 2800); };
  const resetFilters = () => { setSearch(""); setOwner(ALL_OWNERS); setStageFilter(ALL_STAGES); setCodeGroupFilter(ALL_CODE_GROUPS); };

  const importFile = async (file: File) => {
    try {
      const workbook = XLSX.read(await file.arrayBuffer());
      const matrix = XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets[workbook.SheetNames[0]], { header: 1, raw: true, defval: "" });
      const imported = parseImportedSheet(matrix);
      if (!imported.length) throw new Error("empty");
      const response = await fetch("/api/customers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(imported) });
      if (!response.ok) throw new Error("save");
      setCustomers(imported); resetFilters(); notify(`已匯入 ${imported.length} 家客戶，所有同事都會看到`);
    } catch (error) {
      notify(error instanceof Error && error.message === "missing-required-columns"
        ? "匯入失敗：請確認 Excel 至少包含「客編」與「抬頭」兩個欄位"
        : "無法讀取檔案，請確認每筆資料都有客編與抬頭");
    }
  };
  const exportFile = () => {
    const rows = customers.map((item) => exportRow(item));
    const sheet = XLSX.utils.json_to_sheet(rows); sheet["!cols"] = [{wch:12},{wch:28},{wch:12},{wch:14},{wch:10},{wch:10},{wch:10},{wch:12},{wch:22}];
    const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, "發票進度"); XLSX.writeFile(book, `發票進度_${today()}.xlsx`); notify("最新進度已匯出");
  };
  const exportDetail = () => {
    if (!detailStage || !detailCustomers.length) return;
    const rows = detailCustomers.map((item) => exportRow(item));
    const sheet = XLSX.utils.json_to_sheet(rows);
    sheet["!cols"] = [{wch:12},{wch:28},{wch:12},{wch:14},{wch:10},{wch:10},{wch:10},{wch:12},{wch:22}];
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, detailStage.slice(0, 31));
    XLSX.writeFile(book, `${detailStage}明細_${today()}.xlsx`);
    notify(`已匯出${detailStage}明細`);
  };
  const addCustomer = (event: React.FormEvent) => {
    event.preventDefault(); const code = form.code.trim(), title = form.title.trim(), person = form.owner.trim();
    if (!code || !title || !person || !form.registeredDate) return;
    if (customers.some((item) => item.code.toLowerCase() === code.toLowerCase())) return notify("此客編已存在，請使用不同客編");
    const customer: Customer = { id: crypto.randomUUID(), code, title, owner: person, registeredDate: form.registeredDate, sort: normalizeStep(false), keyin: normalizeStep(false), check: normalizeStep(false), upload: normalizeStep(false), updatedAt: new Date().toISOString() };
    setCustomers((items) => [customer, ...items]); saveCustomer(customer);
    setShowAdd(false); notify(`已新增 ${title}`);
  };
  const setStep = (handler: string | null) => {
    if (!editingStep) return;
    setCustomers((items) => items.map((item) => {
      if (item.id !== editingStep.customer.id) return item;
      const next = { ...item, [editingStep.key]: { done: Boolean(handler), handler }, updatedAt: new Date().toISOString() };
      saveCustomer(next); return next;
    }));
    setEditingStep(null);
  };
  const updateCustomer = (id: string, patch: Partial<Pick<Customer, "owner" | "registeredDate">>) => setCustomers((items) => items.map((item) => {
    if (item.id !== id) return item;
    const next = { ...item, ...patch, updatedAt: new Date().toISOString() };
    saveCustomer(next);
    return next;
  }));

  return <main>
    {toast && <div className="toast"><CircleCheck size={17} />{toast}</div>}
    <header className="topbar"><div className="brand"><div className="brand-mark"><FileSpreadsheet size={21} /></div><div><h1>發票進度追蹤</h1><p>營業稅申報進度管理</p></div></div>
      <div className="actions"><input ref={fileInput} type="file" accept=".xlsx,.xls,.csv" hidden onChange={(event) => { const file = event.target.files?.[0]; if (file) importFile(file); event.target.value = ""; }} />
        <button className="button secondary" onClick={() => fileInput.current?.click()}><Upload size={16} />匯入 Excel</button>
        <button className="button secondary" onClick={exportFile}><Download size={16} />匯出進度</button>
        <button className="button primary" onClick={() => { setForm({ code: "", title: "", owner: "", registeredDate: today() }); setShowAdd(true); }}><Plus size={16} />新增客戶</button>
      </div></header>
      <section className="page-shell"><div className="welcome"><div><p className="eyebrow">本期申報進度</p><h2>客戶資料由你自行建立</h2><p>逐筆新增或匯入 Excel，所有同事都會看到最新進度。</p></div><div className="period"><span>共用狀態</span><strong>團隊資料已同步</strong></div></div>
      <section className="stats-grid" aria-label="進度統計">
        <div className="stats-row stats-row-four">
          <StatCard label="總客戶數" value={stats.total} tone="blue" icon={<Users size={20}/>} onClick={() => setDetailStage("總客戶數")} />
          <StatCard label="尚未登記" value={stats.undated} tone="red" icon={<CalendarDays size={20}/>} onClick={() => setDetailStage("尚未登記")} />
          <StatCard label="已登記數" value={stats.registered} tone="teal" icon={<CalendarDays size={20}/>} onClick={() => setDetailStage("已登記數")} />
          <StatCard label="已完成數" value={stats.done} tone="green" icon={<CircleCheck size={20}/>} onClick={() => setDetailStage("已完成數")} />
        </div>
        <div className="stats-row stats-row-four">
          <StatCard label="已整理" value={stats.sorted} tone="orange" icon={<FileSpreadsheet size={20}/>} onClick={() => setDetailStage("已整理")} />
          <StatCard label="已 Key in" value={stats.keyed} tone="purple" icon={<Clock3 size={20}/>} onClick={() => setDetailStage("已 Key in")} />
          <StatCard label="已檢查" value={stats.checked} tone="teal" icon={<Check size={20}/>} onClick={() => setDetailStage("已檢查")} />
          <StatCard label="已上傳" value={stats.uploaded} tone="sky" icon={<Upload size={20}/>} onClick={() => setDetailStage("已上傳")} />
        </div>
      </section>
      <section className="workspace"><div className="workspace-heading"><div><h3>客戶處理進度</h3><p>{customers.length ? (search || owner !== ALL_OWNERS || stageFilter !== ALL_STAGES || codeGroupFilter !== ALL_CODE_GROUPS ? `目前顯示 ${visible.length} 家（篩選後）／共 ${customers.length} 家` : `共 ${customers.length} 家`) : "尚未建立客戶"}</p></div><div className="legend"><span><i className="dot done"/>已完成</span><span><i className="dot waiting"/>尚未完成</span></div></div>
        <div className="filters"><label className="search-box"><Search size={17}/><input placeholder="搜尋客編或抬頭…" value={search} onChange={(event) => setSearch(event.target.value)}/></label>
          <label className="select-box"><Filter size={16}/><select value={codeGroupFilter} onChange={(event) => setCodeGroupFilter(event.target.value)}><option>{ALL_CODE_GROUPS}</option>{CODE_GROUPS.map((group) => <option key={group}>{group}</option>)}</select><ChevronDown size={15}/></label>
          <label className="select-box"><Users size={16}/><select value={owner} onChange={(event) => setOwner(event.target.value)}><option>{ALL_OWNERS}</option>{owners.map((person) => <option key={person}>{person}</option>)}</select><ChevronDown size={15}/></label>
          <label className="select-box"><Filter size={16}/><select value={stageFilter} onChange={(event) => setStageFilter(event.target.value)}><option>{ALL_STAGES}</option><option>待整理</option><option>Key in 中</option><option>待檢查</option><option>待上傳</option><option>已完成</option></select><ChevronDown size={15}/></label></div>
        {!customers.length ? <div className="empty empty-start"><div className="empty-icon"><FileSpreadsheet size={25}/></div><strong>目前還沒有客戶資料</strong><p>按「新增客戶」自行輸入，或從 Excel 匯入。</p><button className="button primary" onClick={() => setShowAdd(true)}><Plus size={15}/>新增第一位客戶</button></div>
        : !visible.length ? <div className="empty"><strong>找不到符合條件的客戶</strong><p>請調整搜尋或篩選條件。</p><button className="button secondary" onClick={resetFilters}>清除篩選</button></div>
        : <div className="table-wrap"><table><thead><tr><th>客編</th><th>抬頭</th><th>負責人</th><th>登記日期</th><th>整理</th><th>Key in</th><th>檢查</th><th>上傳</th><th>目前階段</th><th>操作</th></tr></thead><tbody>{visible.map((item) => <tr key={item.id}><td className="code">{item.code}</td><td className="title-cell">{item.title}</td><td><input className="inline-field owner-field" value={item.owner} placeholder="未填寫" onChange={(event) => updateCustomer(item.id, { owner: event.target.value })} aria-label={`${item.title}的負責人`}/></td><td><input className="inline-field date-field" type="date" value={item.registeredDate} onChange={(event) => updateCustomer(item.id, { registeredDate: event.target.value })} aria-label={`${item.title}的登記日期`}/></td>{(["sort", "keyin", "check", "upload"] as StepKey[]).map((key) => <td key={key}><StepButton step={item[key]} label={STEP_LABELS[key]} onClick={() => setEditingStep({ customer: item, key })}/></td>)}<td><span className={`stage stage-${stage(item).replaceAll(" ", "-")}`}>{stage(item)}</span></td><td><button className="icon-button danger" aria-label={`刪除 ${item.title}`} onClick={() => setDeleting(item)}><Trash2 size={16}/></button></td></tr>)}</tbody></table></div>}
      </section><div className="privacy-note"><Info size={15}/><span>資料已改為團隊共用；同事重新開啟或重新整理即可看到最新狀態。</span></div>
    </section>
    {showAdd && <div className="modal-backdrop" onMouseDown={() => setShowAdd(false)}><div className="modal" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>新增客戶</h3><p>建立一筆新的客戶進度資料</p></div><button className="icon-button" onClick={() => setShowAdd(false)}><X size={19}/></button></div><form onSubmit={addCustomer}><div className="form-grid"><label>客編<span>*</span><input value={form.code} onChange={(event) => setForm({...form, code:event.target.value})} required autoFocus/></label><label>抬頭<span>*</span><input value={form.title} onChange={(event) => setForm({...form, title:event.target.value})} required/></label><label>負責人<span>*</span><input value={form.owner} onChange={(event) => setForm({...form, owner:event.target.value})} required/></label><label>登記日期<span>*</span><input type="date" value={form.registeredDate} onChange={(event) => setForm({...form, registeredDate:event.target.value})} required/></label></div><div className="modal-actions"><button type="button" className="button secondary" onClick={() => setShowAdd(false)}>取消</button><button className="button primary">新增客戶</button></div></form></div></div>}
    {deleting && <div className="modal-backdrop" onMouseDown={() => setDeleting(null)}><div className="modal small" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>刪除客戶</h3><p>確定要刪除「{deleting.title}」嗎？此動作無法復原。</p></div></div><div className="modal-actions"><button className="button secondary" onClick={() => setDeleting(null)}>取消</button><button className="button destructive" onClick={async () => { const target = deleting; setCustomers((items) => items.filter((item) => item.id !== target.id)); setDeleting(null); await fetch("/api/customers", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: target.id }) }); notify(`已刪除 ${target.title}`); }}>確認刪除</button></div></div></div>}
    {editingStep && <div className="modal-backdrop" onMouseDown={() => setEditingStep(null)}><div className="modal small" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>{STEP_LABELS[editingStep.key]}經手人</h3><p>請選擇這一步是誰做的；若要取消完成，請使用下方按鈕。</p></div><button className="icon-button" onClick={() => setEditingStep(null)}><X size={19}/></button></div><div className="handler-options">{HANDLERS.map((handler) => <button key={handler} className={`handler-option ${editingStep.customer[editingStep.key].handler === handler ? "selected" : ""}`} onClick={() => setStep(handler)}>{handler}</button>)}</div><div className="modal-actions"><button className="button secondary" onClick={() => setEditingStep(null)}>關閉</button>{editingStep.customer[editingStep.key].done && <button className="button destructive" onClick={() => setStep(null)}>取消完成</button>}</div></div></div>}
    {detailStage && <div className="modal-backdrop" onMouseDown={() => setDetailStage(null)}><div className="modal detail-modal" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>{detailStage}明細</h3><p>共 {detailCustomers.length} 家客戶</p></div><button className="icon-button" onClick={() => setDetailStage(null)}><X size={19}/></button></div><div className="detail-list">{detailCustomers.length ? detailCustomers.map((item) => <div className="detail-row" key={item.id}><div><strong>{item.title}</strong><span>{item.code}</span></div><div><span>{item.owner || "未填負責人"}</span><span>{item.registeredDate ? displayDate(item.registeredDate) : "未填登記日期"}</span></div><span className={`stage stage-${stage(item).replaceAll(" ", "-")}`}>{stage(item)}</span></div>) : <div className="detail-empty">目前沒有此狀態的客戶</div>}</div><div className="modal-actions"><button className="button secondary" onClick={() => setDetailStage(null)}>關閉</button><button className="button primary" onClick={exportDetail} disabled={!detailCustomers.length}><Download size={15}/>匯出 Excel</button></div></div></div>}
  </main>;
}
