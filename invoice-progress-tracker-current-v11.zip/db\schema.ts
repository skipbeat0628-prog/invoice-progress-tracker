import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const customers = sqliteTable("customers", {
  id: text("id").primaryKey(),
  code: text("code").notNull().unique(),
  title: text("title").notNull(),
  owner: text("owner").notNull().default(""),
  registeredDate: text("registered_date").notNull().default(""),
  sorted: integer("sorted", { mode: "boolean" }).notNull().default(false),
  sortHandler: text("sort_handler"),
  keyed: integer("keyed", { mode: "boolean" }).notNull().default(false),
  keyinHandler: text("keyin_handler"),
  checked: integer("checked", { mode: "boolean" }).notNull().default(false),
  checkHandler: text("check_handler"),
  uploaded: integer("uploaded", { mode: "boolean" }).notNull().default(false),
  uploadHandler: text("upload_handler"),
  updatedAt: text("updated_at").notNull(),
});
