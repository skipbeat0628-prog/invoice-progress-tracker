import { env } from "cloudflare:workers";

type Customer = {
  id: string; code: string; title: string; owner: string; registeredDate: string;
  sort: Step; keyin: Step; check: Step; upload: Step; updatedAt: string;
};
type Step = { done: boolean; handler: string | null };
const normalizeStep = (value: unknown): Step => typeof value === "boolean" ? { done: value, handler: null } : { done: Boolean((value as Step | undefined)?.done), handler: (value as Step | undefined)?.handler || null };

async function ensureSchema() {
  await env.DB.prepare(`CREATE TABLE IF NOT EXISTS customers (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    owner TEXT NOT NULL DEFAULT '',
    registered_date TEXT NOT NULL DEFAULT '',
    sorted INTEGER NOT NULL DEFAULT 0,
    keyed INTEGER NOT NULL DEFAULT 0,
    uploaded INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
  )`).run();
  await env.DB.prepare("CREATE UNIQUE INDEX IF NOT EXISTS idx_customers_code ON customers(code)").run();
  const columns = await env.DB.prepare("PRAGMA table_info(customers)").all();
  const names = new Set((columns.results || []).map((column: Record<string, unknown>) => String(column.name)));
  for (const [name, definition] of [["sort_handler", "TEXT"], ["keyin_handler", "TEXT"], ["checked", "INTEGER NOT NULL DEFAULT 0"], ["check_handler", "TEXT"], ["upload_handler", "TEXT"]]) {
    if (!names.has(name)) await env.DB.prepare(`ALTER TABLE customers ADD COLUMN ${name} ${definition}`).run();
  }
}

const statementFor = (customer: Customer) => env.DB.prepare(`INSERT INTO customers
  (id, code, title, owner, registered_date, sorted, sort_handler, keyed, keyin_handler, checked, check_handler, uploaded, upload_handler, updated_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(id) DO UPDATE SET code=excluded.code, title=excluded.title, owner=excluded.owner,
  registered_date=excluded.registered_date, sorted=excluded.sorted, sort_handler=excluded.sort_handler, keyed=excluded.keyed, keyin_handler=excluded.keyin_handler,
  checked=excluded.checked, check_handler=excluded.check_handler, uploaded=excluded.uploaded, upload_handler=excluded.upload_handler, updated_at=excluded.updated_at`).bind(
    customer.id, customer.code, customer.title, customer.owner || "", customer.registeredDate || "",
    normalizeStep(customer.sort).done ? 1 : 0, normalizeStep(customer.sort).handler,
    normalizeStep(customer.keyin).done ? 1 : 0, normalizeStep(customer.keyin).handler,
    normalizeStep(customer.check).done ? 1 : 0, normalizeStep(customer.check).handler,
    normalizeStep(customer.upload).done ? 1 : 0, normalizeStep(customer.upload).handler, customer.updatedAt,
  );

export async function GET() {
  await ensureSchema();
  const result = await env.DB.prepare("SELECT * FROM customers ORDER BY updated_at DESC").all();
  return Response.json((result.results || []).map((row: Record<string, unknown>) => ({
    id: row.id, code: row.code, title: row.title, owner: row.owner,
    registeredDate: row.registered_date,
    sort: { done: Boolean(row.sorted), handler: row.sort_handler || null }, keyin: { done: Boolean(row.keyed), handler: row.keyin_handler || null },
    check: { done: Boolean(row.checked), handler: row.check_handler || null }, upload: { done: Boolean(row.uploaded), handler: row.upload_handler || null }, updatedAt: row.updated_at,
  })));
}

export async function POST(request: Request) {
  await ensureSchema();
  const customer = await request.json() as Customer;
  await statementFor(customer).run();
  return Response.json({ ok: true });
}

export async function PUT(request: Request) {
  await ensureSchema();
  const customers = await request.json() as Customer[];
  await env.DB.prepare("DELETE FROM customers").run();
  if (customers.length) await env.DB.batch(customers.map(statementFor));
  return Response.json({ ok: true });
}

export async function DELETE(request: Request) {
  await ensureSchema();
  const { id } = await request.json() as { id: string };
  await env.DB.prepare("DELETE FROM customers WHERE id = ?").bind(id).run();
  return Response.json({ ok: true });
}
