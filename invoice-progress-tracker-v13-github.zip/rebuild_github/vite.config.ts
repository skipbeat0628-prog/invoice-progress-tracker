import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  build: {
    outDir: "dist",
  },
  server: {
    proxy: {
      // When running `npm run dev`, forward /api calls to the local Worker
      // started separately with `wrangler dev` (default port 8787).
      "/api": "http://127.0.0.1:8787",
    },
  },
});
