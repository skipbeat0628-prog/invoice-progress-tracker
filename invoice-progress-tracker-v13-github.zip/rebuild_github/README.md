# 發票進度追蹤系統（v13・獨立版）

從 v12 原始碼救回並重建，改為**完全跑在你自己的 Cloudflare 帳號上**，不依賴 OpenAI／ChatGPT 訂閱或任何 AI 平台代管服務。

## 這一版跟舊版的差異

- 前端從 Next.js 改為 **Vite + React**（部署更單純，不需要 Node.js 伺服器）
- 後端從「OpenAI Apps 代管」改為 **Cloudflare Worker**，直接讀寫你自己 Cloudflare 帳號裡的 D1 資料庫
- 拿掉了 `chatgpt-auth.ts`（ChatGPT 專屬登入機制，原本前端其實也沒在用它）
- 介面、功能、樣式（`globals.css`）**完全沿用**救回來的原始碼，操作方式不變
- 資料結構（客編、抬頭、負責人、登記日期、整理／KeyIn／檢查／上傳）維持一致

## 部署前準備

1. 一個 Cloudflare 帳號（免費方案即可）
2. 本機安裝 Node.js（18 以上）
3. 終端機執行 `npm install -g wrangler`（或直接用 `npx wrangler`）

## 部署步驟

```bash
# 1. 安裝套件
npm install

# 2. 登入你自己的 Cloudflare 帳號
npx wrangler login

# 3. 建立一個新的 D1 資料庫（只需做一次）
npx wrangler d1 create invoice_progress_db
```

第 3 步執行完，終端機會印出一段像這樣的設定：

```
[[d1_databases]]
binding = "DB"
database_name = "invoice_progress_db"
database_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
```

把 `database_id` 複製起來，貼到 `wrangler.toml` 裡取代 `REPLACE_WITH_YOUR_D1_DATABASE_ID`。

```bash
# 4. 建立資料表
npm run db:migrate:remote

# 5.（選用）把你之前的 453 筆客戶資料匯回去
#    這個檔案是我用你上傳的備份 JSON 產生的，
#    只在你的電腦上，不會被提交到 GitHub（.gitignore 已排除）
npm run db:import:remote

# 6. 打包前端 + 部署 Worker
npm run deploy
```

部署完成後，終端機會顯示一個 `*.workers.dev` 網址，這就是新網站的位置。如果你有自己的網域，可以之後在 Cloudflare Dashboard 裡加一個自訂網域。

## 本機開發（想先測試再部署）

開兩個終端機視窗：

```bash
# 視窗 1：啟動本機 Worker（含本機測試用 D1）
npm run db:migrate:local
npx wrangler dev

# 視窗 2：啟動前端開發伺服器
npm run dev
```

瀏覽器打開 `http://localhost:5173` 即可測試，API 會自動轉發到本機 Worker。

## 重要提醒

- `migrations/0002_import_backup.sql` 內含真實客戶資料（公司名稱等），**已加入 `.gitignore`，不要手動移除**
- 目前尚未包含「每日備份到 Google Drive」功能 —— 這需要你提供 Google 服務帳號憑證（OAuth），等基本網站部署、確認資料正常後，我可以幫你加回這個功能
- `HANDLERS`（經手人名單：小玉、Grace、蕙琪、玲玲、俐蓉）目前是寫死在 `src/App.tsx` 裡，跟原本救回的程式碼一致；如果人員異動，直接在該檔案裡修改陣列即可
