import { sqliteTable, text, integer } from "drizzle-orm/sqlite-core";

// Mirrors the Customer shape used by the frontend (src/App.tsx):
//   { id, code, title, owner, registeredDate,
//     sort: {done, handler}, keyin: {done, handler},
//     check: {done, handler}, upload: {done, handler}, updatedAt }
// SQLite/D1 has no nested objects, so each step is flattened into
// a `<step>_done` (0/1) and `<step>_handler` column pair.
export const customers = sqliteTable("customers", {
  id: text("id").primaryKey(),
  code: text("code").notNull(),
  title: text("title").notNull(),
  owner: text("owner").notNull().default(""),
  registeredDate: text("registered_date").notNull().default(""),

  sortDone: integer("sort_done", { mode: "boolean" }).notNull().default(false),
  sortHandler: text("sort_handler"),

  keyinDone: integer("keyin_done", { mode: "boolean" }).notNull().default(false),
  keyinHandler: text("keyin_handler"),

  checkDone: integer("check_done", { mode: "boolean" }).notNull().default(false),
  checkHandler: text("check_handler"),

  uploadDone: integer("upload_done", { mode: "boolean" }).notNull().default(false),
  uploadHandler: text("upload_handler"),

  updatedAt: text("updated_at").notNull(),
});
