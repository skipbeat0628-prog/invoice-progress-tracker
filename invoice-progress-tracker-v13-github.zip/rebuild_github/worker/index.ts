import { drizzle } from "drizzle-orm/d1";
import { eq } from "drizzle-orm";
import { customers } from "./schema";

export interface Env {
  DB: D1Database;
  ASSETS: Fetcher;
}

type Step = { done: boolean; handler: string | null };
type Customer = {
  id: string;
  code: string;
  title: string;
  owner: string;
  registeredDate: string;
  sort: Step;
  keyin: Step;
  check: Step;
  upload: Step;
  updatedAt: string;
};

type CustomerRow = typeof customers.$inferSelect;

// DB row (flat) <-> Customer (nested) — matches the shape the frontend
// (src/App.tsx) already expects from GET /api/customers.
function rowToCustomer(row: CustomerRow): Customer {
  return {
    id: row.id,
    code: row.code,
    title: row.title,
    owner: row.owner,
    registeredDate: row.registeredDate,
    sort: { done: row.sortDone, handler: row.sortHandler },
    keyin: { done: row.keyinDone, handler: row.keyinHandler },
    check: { done: row.checkDone, handler: row.checkHandler },
    upload: { done: row.uploadDone, handler: row.uploadHandler },
    updatedAt: row.updatedAt,
  };
}

function customerToRow(c: Customer) {
  return {
    id: c.id,
    code: c.code,
    title: c.title,
    owner: c.owner ?? "",
    registeredDate: c.registeredDate ?? "",
    sortDone: Boolean(c.sort?.done),
    sortHandler: c.sort?.handler ?? null,
    keyinDone: Boolean(c.keyin?.done),
    keyinHandler: c.keyin?.handler ?? null,
    checkDone: Boolean(c.check?.done),
    checkHandler: c.check?.handler ?? null,
    uploadDone: Boolean(c.upload?.done),
    uploadHandler: c.upload?.handler ?? null,
    updatedAt: c.updatedAt ?? new Date().toISOString(),
  };
}

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/api/customers") {
      const db = drizzle(env.DB, { schema: { customers } });

      try {
        if (request.method === "GET") {
          const rows = await db.select().from(customers).all();
          return json(rows.map(rowToCustomer));
        }

        if (request.method === "POST") {
          // Upsert a single customer (used for one-field edits and new customers).
          const body = (await request.json()) as Customer;
          if (!body?.id || !body.code || !body.title) {
            return json({ error: "missing id/code/title" }, 400);
          }
          const row = customerToRow(body);
          await db
            .insert(customers)
            .values(row)
            .onConflictDoUpdate({ target: customers.id, set: row })
            .run();
          return json({ ok: true });
        }

        if (request.method === "PUT") {
          // Full replace — used by Excel import, JSON restore, and "clear all".
          const body = (await request.json()) as Customer[];
          if (!Array.isArray(body)) return json({ error: "expected array" }, 400);

          const rows = body.map(customerToRow);
          await db.batch([
            db.delete(customers),
            ...(rows.length ? [db.insert(customers).values(rows)] : []),
          ] as any);
          return json({ ok: true, count: rows.length });
        }

        if (request.method === "DELETE") {
          const body = (await request.json()) as { id?: string };
          if (!body?.id) return json({ error: "missing id" }, 400);
          await db.delete(customers).where(eq(customers.id, body.id)).run();
          return json({ ok: true });
        }

        return json({ error: "method not allowed" }, 405);
      } catch (err) {
        console.error(err);
        return json({ error: "internal error" }, 500);
      }
    }

    // Everything else: serve the built Vite frontend (dist/) via the
    // Workers static assets binding configured in wrangler.toml.
    return env.ASSETS.fetch(request);
  },
};
