CREATE TABLE IF NOT EXISTS customers (
  id              TEXT PRIMARY KEY,
  code            TEXT NOT NULL,
  title           TEXT NOT NULL,
  owner           TEXT NOT NULL DEFAULT '',
  registered_date TEXT NOT NULL DEFAULT '',

  sort_done       INTEGER NOT NULL DEFAULT 0,
  sort_handler    TEXT,

  keyin_done      INTEGER NOT NULL DEFAULT 0,
  keyin_handler   TEXT,

  check_done      INTEGER NOT NULL DEFAULT 0,
  check_handler   TEXT,

  upload_done     INTEGER NOT NULL DEFAULT 0,
  upload_handler  TEXT,

  updated_at      TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS customers_code_unique ON customers (code);
