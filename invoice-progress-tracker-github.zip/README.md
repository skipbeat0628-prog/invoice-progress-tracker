# 發票進度追蹤｜營業稅申報管理

這是目前線上「發票進度追蹤」網站的完整原始碼備份，可放入 GitHub，供其他 AI 或工程師接手維護。

線上版本：<https://invoice-progress-tracker.hb8hvkq8st.chatgpt.site>

## 主要功能

- 客戶新增、刪除與全部清除
- Excel 匯入與進度明細匯出
- JSON 備份、還原與指定檔案儲存
- 每日開啟網站時自動更新一次已授權的本機 JSON 備份
- 客編、抬頭、負責人、處理階段篩選
- 多客編搜尋（空格、逗號、頓號或分號分隔）
- 多選客戶與批次處理
- 批次設定或取消登記日期
- 批次完成或取消「整理、Key in、檢查、上傳」並指定經手人
- 團隊共用資料與定時同步
- 客編排序規則：例如 A05 排序時視為 A050，但畫面保留 A05

## 技術架構

- React 19 + TypeScript
- Next.js 16 相容路由
- Vinext + Vite
- Cloudflare Worker
- Cloudflare D1（綁定名稱 `DB`）
- SheetJS (`xlsx`) 處理 Excel

資料表由 `app/api/customers/route.ts` 在第一次存取時建立。前端主要程式在 `app/page.tsx`，樣式在 `app/globals.css`。

## 本機啟動

需求：Node.js 22.13 以上。

```bash
npm ci
npm run dev
```

正式編譯：

```bash
npm run build
```

## 部署注意事項

`.openai/hosting.json` 是目前 ChatGPT Sites 專案的部署設定，資料庫綁定名稱為 `DB`。若要在另一個帳號或平台部署，請建立新的資料庫與專案設定。

若改用一般 Cloudflare Workers，需確保 Worker 取得名為 `DB` 的 D1 binding。若改用 Vercel、Supabase、Firebase 或其他平台，必須重寫 `app/api/customers/route.ts` 的資料庫存取層，前端資料格式可維持不變。

## 備份與還原

「儲存」按鈕會將完整客戶資料寫入 JSON。第一次由使用者選擇檔案位置，之後更新同一檔案。網站關閉時，瀏覽器無法執行本機自動備份。

## 專案交接

請先閱讀 [HANDOFF.md](HANDOFF.md)，其中記錄資料模型、API、重要行為及修改時最容易踩到的地方。

## 專案包不包含

- `node_modules`、編譯輸出與本機快取
- Git 歷史與存取憑證
- 線上 D1 資料庫中的客戶資料

客戶資料應另外使用網站的「儲存」按鈕匯出 JSON，不應提交到公開 GitHub。

## 原始框架維護說明

## Sites Lifecycle

The Sites lifecycle CLI runs the locked dependency install before returning this checkout. Edit the source under `app/`, then checkpoint when a coherent milestone is ready to inspect or share. The remote Sites builder runs `npm run build` against the pushed commit. Do not repeat install or build as a normal pre-checkpoint step.

This starter does not use `wrangler.jsonc`.

`install:ci` is intentionally a single, non-retrying `npm ci`. It refuses a concurrent install for the same project, consumes a matching image-seeded npm cache with `--prefer-offline` while retaining registry fallback for a missing cache object, otherwise downloads and verifies the complete vinext tarball recorded in `package-lock.json`, limits npm to one socket, and terminates a stalled install. `build` applies a short timeout and then validates the Sites artifact. These helpers target Linux and use GNU `timeout`; they are not native macOS scripts.

Scripts that need writable project-scoped home, npm, XDG, and temporary paths use `scripts/sites-env.sh`. The `dev` and `start` scripts honor the caller's runtime environment and keep Wrangler logs inside the checkout. The generated `.sites-runtime/` directory is disposable and ignored by Git.

## Included Shape

- edit site code under `app/`
- `app/chatgpt-auth.ts` provides optional dispatch-owned ChatGPT sign-in helpers
- `.openai/hosting.json` declares optional Sites D1 and R2 bindings
- `vite.config.ts` simulates declared bindings for local development
- `db/index.ts` reads the D1 binding from the Cloudflare Worker environment
- `db/schema.ts` starts intentionally empty
- `examples/d1/` contains an optional D1 example surface
- `drizzle.config.ts` supports local migration generation when needed

## Workspace Auth Headers

OpenAI workspace sites can read the current user's email from
`oai-authenticated-user-email`.

SIWC-authenticated workspace sites may also receive
`oai-authenticated-user-full-name` when the user's SIWC profile has a non-empty
`name` claim. The full-name value is percent-encoded UTF-8 and is accompanied by
`oai-authenticated-user-full-name-encoding: percent-encoded-utf-8`.

Treat the full name as optional and fall back to email when it is absent:

```tsx
import { headers } from "next/headers";

export default async function Home() {
  const requestHeaders = await headers();
  const email = requestHeaders.get("oai-authenticated-user-email");
  const encodedFullName = requestHeaders.get("oai-authenticated-user-full-name");
  const fullName =
    encodedFullName &&
    requestHeaders.get("oai-authenticated-user-full-name-encoding") ===
      "percent-encoded-utf-8"
      ? decodeURIComponent(encodedFullName)
      : null;

  const displayName = fullName ?? email;
  // ...
}
```

## Optional Dispatch-Owned ChatGPT Sign-In

Import the ready-to-use helpers from `app/chatgpt-auth.ts` when the site needs
optional or required ChatGPT sign-in:

- Use `getChatGPTUser()` for optional signed-in UI.
- Use `requireChatGPTUser(returnTo)` for server-rendered pages that should send
  anonymous visitors through Sign in with ChatGPT.
- Use `chatGPTSignInPath(returnTo)` and `chatGPTSignOutPath(returnTo)` for
  browser links or actions.
- Pass a same-origin relative `returnTo` path for the destination after sign-in
  or sign-out. The helper validates and safely encodes it.
- Mark protected pages with `export const dynamic = "force-dynamic"` because
  they depend on per-request identity headers.

Dispatch owns `/signin-with-chatgpt`, `/signout-with-chatgpt`, `/callback`, the
OAuth cookies, and identity header injection. Do not implement app routes for
those reserved paths. Routes that do not import and call the helper remain
anonymous-compatible.

SIWC establishes identity only; it does not prove workspace membership. Use the
Sites hosting platform's access policy controls for workspace-wide restrictions,
or enforce explicit server-side membership or allowlist checks.

Use SIWC for account pages, user-specific dashboards, saved records, and write
actions tied to the current ChatGPT user. Leave public content anonymous.

## Diagnostic Commands

- `npm run install:ci`: perform the one bounded lockfile install
- `npm run dev`: start the Vite/Vinext development server
- `npm run build`: build and validate the deployable Sites artifact
- `npm run start`: start the built Vinext application
- `npm test`: build, validate, and verify the rendered development-preview metadata
- `npm run validate:artifact`: recheck an existing artifact's manifest and ESM `default.fetch` export
- `npm run db:generate`: generate Drizzle migrations after schema changes

Use build and validation commands for targeted diagnosis after a remote failure, not as part of the normal checkpoint path.

The timeout defaults can be overridden for a controlled canary with `SITES_INSTALL_TIMEOUT`, `SITES_INSTALL_KILL_AFTER`, `SITES_BUILD_TIMEOUT`, and `SITES_BUILD_KILL_AFTER`. A timeout fails the command; the helpers never retry an unchanged install or build.

## Learn More

- [vinext Documentation](https://github.com/cloudflare/vinext)
- [Drizzle D1 Guide](https://orm.drizzle.team/docs/get-started/d1-new)
