# 接手維護說明

## 程式入口

| 範圍 | 檔案 | 說明 |
|---|---|---|
| 主畫面與互動 | `app/page.tsx` | 列表、篩選、批次、Excel、JSON |
| 全站樣式 | `app/globals.css` | 桌面與行動版 |
| 營業稅 API | `app/api/customers/route.ts` | D1 CRUD 與資料表初始化 |
| 切傳票 API | `app/api/vouchers/route.ts` | D1 CRUD 與資料表初始化 |
| 登入驗證 | `app/password-auth.ts` | 密碼雜湊、Session 與 Cookie |
| Worker 入口 | `worker/index.ts` | Vinext Worker 入口 |
| 執行設定 | `vite.config.ts` | Vinext、Sites、D1 綁定 |

`app/api/clients` 是早期相容路由，目前主畫面使用 `/api/customers`。確認沒有外部依賴後才考慮移除。

## 資料模型

```ts
type Step = { done: boolean; handler: string | null };
type Customer = {
  id: string;
  code: string;
  title: string;
  owner: string;
  registeredDate: string;
  sort: Step;
  keyin: Step;
  check: Step;
  upload: Step;
  updatedAt: string;
};
```

## API `/api/customers`

- `GET`：取得全部客戶
- `POST`：依 `id` 新增或更新單一客戶
- `PUT`：以傳入陣列取代全部客戶
- `DELETE`：傳入 `{ "id": "..." }` 刪除單一客戶

D1 資料表為 `customers`，由 API 的 `ready()` 自動建立。

切傳票 API 為 `/api/vouchers`，資料表為 `voucher_customers`，流程鍵為 `inspect`、`extra`、`journal`、`bind`、`restore`。切傳票操作頁採電腦版完整橫向顯示，不呈現登記日期；修改時不得連帶變更營業稅模組。

## 不可遺漏的產品規則

1. 多客編搜尋以空格、半形／全形逗號、頓號、半形／全形分號切開。
2. 多個搜尋詞時客編採精確比對，避免 `A01` 誤選 `A010`。
3. 切換搜尋或篩選不會清除已勾選客戶，方便分批搜尋後批次處理。
4. 全選只作用於目前顯示的結果。
5. `A05` 排序時視為 `A050`，但不可修改畫面顯示值。
6. 批次處理必須支援完成與取消；登記日期支援設定與取消登記。
7. 資料寫入共用 D1，前端每 10 秒重新讀取一次。
8. 入口進度以全部流程皆完成的客戶家數計算，不以流程項目數計算。
9. 只有營業稅顯示未收到資料家數；切傳票不顯示。
10. 不可移除任何流程的經手人功能。

## Excel 格式

至少需一組客編與抬頭。可辨識欄名：

- 客編：`客編`、`客戶編號`、`客戶代號`、`編號`
- 抬頭：`抬頭`、`客戶名稱`、`公司名稱`

同一張工作表可橫向放多組客編／抬頭。其他可選欄位包含負責人、登記日期、四個工作階段及各階段經手人。

## JSON 儲存

- 使用瀏覽器 File System Access API。
- 第一次由使用者選擇 JSON 檔案，handle 存在 IndexedDB。
- 之後覆寫同一檔案。
- 每天第一次載入且瀏覽器仍有權限時，自動寫入一次。
- 不支援此 API 的瀏覽器會改成下載 JSON。
- 這不是伺服器排程；網站未開啟時不會執行。

若要電腦關機時仍每天備份到 Google Drive，需另建 Google OAuth、Drive API、伺服器排程與安全的 token 儲存。

## 修改後檢查

```bash
npm ci
npm run build
npm test
```

人工確認新增客戶、Excel 匯入、JSON 儲存／還原、多客編搜尋、跨搜尋保留勾選、全選目前結果、批次設定與取消、刪除及手機版。

## 安全

- 不要把真實客戶 JSON、Excel 或 D1 資料提交到公開 GitHub。
- 不要提交 `.env`、OAuth token、API key 或雲端硬碟授權。
- GitHub 交接版不含現行密碼雜湊；部署時必須設定 `APP_PASSWORD_HASH`。
