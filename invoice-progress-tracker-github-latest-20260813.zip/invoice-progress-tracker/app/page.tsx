"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  CalendarDays, Check, ChevronDown, ChevronUp, Circle, CircleCheck, Clock3, Download,
  ArrowLeft, BookOpenCheck, FileSpreadsheet, Filter, Home, Info, LockKeyhole, LogOut, Plus, Save, Search, Trash2, Upload, Users, X,
} from "lucide-react";
import * as XLSX from "xlsx";

type Customer = {
  id: string; code: string; title: string; owner: string; registeredDate: string;
  sort: Step; keyin: Step; check: Step; upload: Step; updatedAt: string;
};
type Step = { done: boolean; handler: string | null };
type StepKey = "sort" | "keyin" | "check" | "upload";
const HANDLERS = ["小玉", "Grace", "蕙琪", "玲玲", "俐蓉"];
const STEP_LABELS: Record<StepKey, string> = { sort: "整理", keyin: "Key in", check: "檢查", upload: "上傳" };

const STORAGE_KEY = "invoice-progress-customers-v1";
const ALL_OWNERS = "全部負責人";
const ALL_STAGES = "全部階段";
const ALL_CODE_GROUPS = "全部客編";
const CODE_GROUPS = ["A0", "A1", "A2", "A3", "A4", "A5", "所有 O", "LA／LC", "其他"];
const CODE_HEADERS = ["客編", "客戶編號", "客戶代號", "編號"];
const TITLE_HEADERS = ["抬頭", "客戶名稱", "公司名稱"];

const today = () => {
  const date = new Date();
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};
const textValue = (value: unknown) => String(value ?? "").trim();
const findValue = (row: Record<string, unknown>, headers: string[]) => {
  for (const header of headers) if (header in row) return row[header];
  return undefined;
};
const truthyExcel = (value: unknown) => ["1", "true", "yes", "y", "是", "完成", "v", "✓", "✔"].includes(textValue(value).toLowerCase());
const excelDate = (value: unknown) => {
  if (typeof value === "number") {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed) return `${parsed.y}-${String(parsed.m).padStart(2, "0")}-${String(parsed.d).padStart(2, "0")}`;
  }
  const match = textValue(value).replaceAll("/", "-").match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  return match ? `${match[1]}-${match[2].padStart(2, "0")}-${match[3].padStart(2, "0")}` : "";
};
const normalizeStep = (value: unknown): Step => typeof value === "boolean"
  ? { done: value, handler: null }
  : { done: Boolean((value as Step | undefined)?.done), handler: (value as Step | undefined)?.handler || null };
const normalizeCustomer = (value: Record<string, unknown>): Customer => ({
  ...value,
  sort: normalizeStep(value.sort ?? value.sorted), keyin: normalizeStep(value.keyin ?? value.keyed),
  check: normalizeStep(value.check ?? value.checked), upload: normalizeStep(value.upload ?? value.uploaded),
}) as Customer;
const stage = (customer: Customer) => customer.upload.done ? "已完成" : customer.check.done ? "待上傳" : customer.keyin.done ? "待檢查" : customer.sort.done ? "Key in 中" : "待整理";
const codeGroup = (code: string) => {
  const normalized = code.trim().toUpperCase();
  for (const prefix of ["A0", "A1", "A2", "A3", "A4", "A5"]) if (normalized.startsWith(prefix)) return prefix;
  if (normalized.startsWith("O")) return "所有 O";
  if (normalized.startsWith("LA") || normalized.startsWith("LC")) return "LA／LC";
  return "其他";
};
const displayDate = (value: string) => value ? value.replaceAll("-", "/") : "—";
const sortableCode = (code: string) => code.trim().toUpperCase().replace(/^(A)(\d+)$/, (_, prefix, digits) => `${prefix}${digits.padEnd(3, "0")}`);
const sortByCode = (a: Customer, b: Customer) => sortableCode(a.code).localeCompare(sortableCode(b.code), "zh-TW", { numeric: true, sensitivity: "base" });

const openBackupDb = () => new Promise<IDBDatabase>((resolve, reject) => {
  const request = indexedDB.open("invoice-progress-backup", 1);
  request.onupgradeneeded = () => request.result.createObjectStore("settings");
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error);
});
const backupSetting = async <T,>(mode: "get" | "put", value?: T, key = "backup") => {
  const db = await openBackupDb();
  return new Promise<T | undefined>((resolve, reject) => {
    const tx = db.transaction("settings", mode === "get" ? "readonly" : "readwrite");
    const request = mode === "get" ? tx.objectStore("settings").get(key) : tx.objectStore("settings").put(value, key);
    request.onsuccess = () => resolve(request.result as T | undefined);
    request.onerror = () => reject(request.error);
    tx.oncomplete = () => db.close();
  });
};
const exportRow = (item: Customer) => ({
  客編: item.code, 抬頭: item.title, 負責人: item.owner, 登記日期: displayDate(item.registeredDate),
  整理: item.sort.done ? "完成" : "未完成", 整理經手人: item.sort.handler || "",
  "Key in": item.keyin.done ? "完成" : "未完成", "Key in 經手人": item.keyin.handler || "",
  檢查: item.check.done ? "完成" : "未完成", 檢查經手人: item.check.handler || "",
  上傳: item.upload.done ? "完成" : "未完成", 上傳經手人: item.upload.handler || "",
  目前階段: stage(item), 最後更新時間: new Date(item.updatedAt).toLocaleString("zh-TW"),
});

export function parseImportedRows(rows: Record<string, unknown>[]): Customer[] {
  if (!rows.length) throw new Error("empty");
  const headers = Object.keys(rows[0]);
  if (!CODE_HEADERS.some((key) => headers.includes(key)) || !TITLE_HEADERS.some((key) => headers.includes(key))) {
    throw new Error("missing-required-columns");
  }
  const now = new Date().toISOString();
  return rows.map((row, index) => ({
    id: `${Date.now()}-${index}`,
    code: textValue(findValue(row, CODE_HEADERS)),
    title: textValue(findValue(row, TITLE_HEADERS)),
    owner: textValue(row["負責人"]),
    registeredDate: excelDate(row["登記日期"] ?? row["日期"]),
    sort: { done: truthyExcel(row["整理"]), handler: textValue(row["整理經手人"]) || null },
    keyin: { done: truthyExcel(row["Key in"] ?? row["Key In"]), handler: textValue(row["Key in 經手人"]) || null },
    check: { done: truthyExcel(row["檢查"]), handler: textValue(row["檢查經手人"]) || null },
    upload: { done: truthyExcel(row["上傳"]), handler: textValue(row["上傳經手人"]) || null },
    updatedAt: now,
  })).filter((customer) => customer.code && customer.title);
}
export function parseImportedSheet(matrix: unknown[][]): Customer[] {
  if (!matrix.length) throw new Error("empty");
  const headerRowIndex = matrix.findIndex((row) => row.some((cell) => CODE_HEADERS.includes(textValue(cell))) && row.some((cell) => TITLE_HEADERS.includes(textValue(cell))));
  if (headerRowIndex < 0) throw new Error("missing-required-columns");
  const headers = matrix[headerRowIndex].map(textValue);
  const codeColumns = headers.map((header, index) => CODE_HEADERS.includes(header) ? index : -1).filter((index) => index >= 0);
  const groups = codeColumns.map((codeColumn, groupIndex) => {
    const end = codeColumns[groupIndex + 1] ?? headers.length;
    const titleColumn = headers.findIndex((header, index) => index > codeColumn && index < end && TITLE_HEADERS.includes(header));
    if (titleColumn < 0) return null;
    const findOptional = (names: string[]) => headers.findIndex((header, index) => index > codeColumn && index < end && names.includes(header));
    return { codeColumn, titleColumn, ownerColumn: findOptional(["負責人"]), dateColumn: findOptional(["登記日期", "日期"]), sortedColumn: findOptional(["整理"]), keyedColumn: findOptional(["Key in", "Key In"]), checkedColumn: findOptional(["檢查"]), uploadedColumn: findOptional(["上傳"]), sortHandlerColumn: findOptional(["整理經手人"]), keyinHandlerColumn: findOptional(["Key in 經手人"]), checkHandlerColumn: findOptional(["檢查經手人"]), uploadHandlerColumn: findOptional(["上傳經手人"]) };
  }).filter((group): group is NonNullable<typeof group> => Boolean(group));
  if (!groups.length) throw new Error("missing-required-columns");
  const now = new Date().toISOString();
  const imported: Customer[] = [];
  for (let rowIndex = headerRowIndex + 1; rowIndex < matrix.length; rowIndex++) {
    const row = matrix[rowIndex];
    for (const group of groups) {
      const code = textValue(row[group.codeColumn]);
      const title = textValue(row[group.titleColumn]);
      if (!code || !title) continue;
      imported.push({
        id: crypto.randomUUID(), code, title,
        owner: group.ownerColumn >= 0 ? textValue(row[group.ownerColumn]) : "",
        registeredDate: group.dateColumn >= 0 ? excelDate(row[group.dateColumn]) : "",
        sort: { done: group.sortedColumn >= 0 ? truthyExcel(row[group.sortedColumn]) : false, handler: group.sortHandlerColumn >= 0 ? textValue(row[group.sortHandlerColumn]) || null : null },
        keyin: { done: group.keyedColumn >= 0 ? truthyExcel(row[group.keyedColumn]) : false, handler: group.keyinHandlerColumn >= 0 ? textValue(row[group.keyinHandlerColumn]) || null : null },
        check: { done: group.checkedColumn >= 0 ? truthyExcel(row[group.checkedColumn]) : false, handler: group.checkHandlerColumn >= 0 ? textValue(row[group.checkHandlerColumn]) || null : null },
        upload: { done: group.uploadedColumn >= 0 ? truthyExcel(row[group.uploadedColumn]) : false, handler: group.uploadHandlerColumn >= 0 ? textValue(row[group.uploadHandlerColumn]) || null : null },
        updatedAt: now,
      });
    }
  }
  return Array.from(new Map(imported.map((customer) => [customer.code.toLowerCase(), customer])).values());
}

function StatCard({ label, value, tone, icon, onClick }: { label: string; value: number; tone: string; icon: React.ReactNode; onClick: () => void }) {
  return <button className="stat-card" onClick={onClick} aria-label={`查看${label}明細`}><div className={`stat-icon ${tone}`}>{icon}</div><div><p>{label}</p><strong>{value}</strong></div><span className="stat-hint">查看明細</span></button>;
}

function StepButton({ step, label, onClick }: { step: Step; label: string; onClick: () => void }) {
  return <button className={`step-button ${step.done ? "is-done" : ""}`} onClick={onClick} aria-pressed={step.done}>
    <span>{step.done ? <Check size={14} strokeWidth={3} /> : <Plus size={13} />}</span>{step.done ? `${label}．${step.handler || "未指定"}` : `＋${label}`}
  </button>;
}

type VoucherKey = "inspect" | "extra" | "journal" | "bind" | "restore";
type VoucherCustomer = {
  id: string; code: string; title: string; owner: string; registeredDate: string;
  inspect: Step; extra: Step; journal: Step; bind: Step; restore: Step; updatedAt: string;
};
const VOUCHER_KEYS: VoucherKey[] = ["inspect", "extra", "journal", "bind", "restore"];
const VOUCHER_LABELS: Record<VoucherKey, string> = { inspect: "檢查", extra: "算另計", journal: "切傳票", bind: "裝訂傳票", restore: "歸位" };
const normalizeVoucher = (value: Record<string, unknown>): VoucherCustomer => ({
  ...value, inspect: normalizeStep(value.inspect), extra: normalizeStep(value.extra), journal: normalizeStep(value.journal),
  bind: normalizeStep(value.bind), restore: normalizeStep(value.restore),
}) as VoucherCustomer;
const voucherStage = (item: VoucherCustomer) => item.restore.done ? "已完成" : item.bind.done ? "待歸位" : item.journal.done ? "待裝訂傳票" : item.extra.done ? "待切傳票" : item.inspect.done ? "待算另計" : "待檢查";
const voucherSort = (a: VoucherCustomer, b: VoucherCustomer) => sortableCode(a.code).localeCompare(sortableCode(b.code), "zh-TW", { numeric: true, sensitivity: "base" });
const voucherExportRow = (item: VoucherCustomer) => ({
  客編: item.code, 抬頭: item.title, 負責人: item.owner,
  ...Object.fromEntries(VOUCHER_KEYS.flatMap((key) => [[VOUCHER_LABELS[key], item[key].done ? "完成" : "未完成"], [`${VOUCHER_LABELS[key]}經手人`, item[key].handler || ""]])),
  目前階段: voucherStage(item), 最後更新時間: new Date(item.updatedAt).toLocaleString("zh-TW"),
});

function VoucherTracker({ onBack, onLogout }: { onBack: () => void; onLogout: () => void }) {
  const [items, setItems] = useState<VoucherCustomer[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [search, setSearch] = useState("");
  const [owner, setOwner] = useState(ALL_OWNERS);
  const [stageFilter, setStageFilter] = useState(ALL_STAGES);
  const [codeGroupFilter, setCodeGroupFilter] = useState(ALL_CODE_GROUPS);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [toast, setToast] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [showClearAll, setShowClearAll] = useState(false);
  const [showBatch, setShowBatch] = useState(false);
  const [deleting, setDeleting] = useState<VoucherCustomer | null>(null);
  const [editing, setEditing] = useState<{ item: VoucherCustomer; key: VoucherKey } | null>(null);
  const [detail, setDetail] = useState<string | null>(null);
  const [pendingRestore, setPendingRestore] = useState<VoucherCustomer[] | null>(null);
  const [batchItem, setBatchItem] = useState<VoucherKey>("inspect");
  const [batchStatus, setBatchStatus] = useState<"done" | "cancel">("done");
  const [batchHandler, setBatchHandler] = useState(HANDLERS[0]);
  const [batchSaving, setBatchSaving] = useState(false);
  const [form, setForm] = useState({ code: "", title: "", owner: "" });
  const fileInput = useRef<HTMLInputElement>(null);
  const restoreInput = useRef<HTMLInputElement>(null);
  const backupHandle = useRef<any>(null);
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(""), 2800); };

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        const response = await fetch("/api/vouchers", { cache: "no-store" });
        if (!response.ok) throw new Error();
        const rows = (await response.json() as Record<string, unknown>[]).map(normalizeVoucher);
        if (active) { setItems(rows); setLoaded(true); }
      } catch { if (active) { setLoaded(true); notify("切傳票資料載入失敗，請重新整理再試"); } }
    };
    load(); const timer = window.setInterval(load, 10000);
    return () => { active = false; window.clearInterval(timer); };
  }, []);

  const persist = async (item: VoucherCustomer) => {
    const response = await fetch("/api/vouchers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(item) });
    if (!response.ok) notify("儲存失敗，請重新整理後再試");
  };
  const resetFilters = () => { setSearch(""); setOwner(ALL_OWNERS); setStageFilter(ALL_STAGES); setCodeGroupFilter(ALL_CODE_GROUPS); };
  const owners = useMemo(() => Array.from(new Set(items.map((item) => item.owner).filter(Boolean))).sort(), [items]);
  const visible = useMemo(() => {
    const terms = search.trim().toLowerCase().split(/[\s,，、;；]+/).filter(Boolean), multi = terms.length > 1;
    return items.filter((item) => (!terms.length || terms.some((term) => multi ? item.code.trim().toLowerCase() === term : item.code.toLowerCase().includes(term) || item.title.toLowerCase().includes(term)))
      && (owner === ALL_OWNERS || item.owner === owner) && (stageFilter === ALL_STAGES || voucherStage(item) === stageFilter)
      && (codeGroupFilter === ALL_CODE_GROUPS || codeGroup(item.code) === codeGroupFilter)).sort(voucherSort);
  }, [items, search, owner, stageFilter, codeGroupFilter]);
  const selected = useMemo(() => items.filter((item) => selectedIds.has(item.id)), [items, selectedIds]);
  const allVisibleSelected = visible.length > 0 && visible.every((item) => selectedIds.has(item.id));
  const stats = useMemo(() => Object.fromEntries([["total", items.length], ["done", items.filter((x) => VOUCHER_KEYS.every((key) => x[key].done)).length], ...VOUCHER_KEYS.map((key) => [key, items.filter((x) => x[key].done).length])]) as Record<string, number>, [items]);
  const detailItems = useMemo(() => (detail === "總客戶數" ? items : detail === "已完成數" ? items.filter((x) => VOUCHER_KEYS.every((key) => x[key].done)) : VOUCHER_KEYS.includes(detail as VoucherKey) ? items.filter((x) => x[detail as VoucherKey].done) : items.filter((x) => voucherStage(x) === detail)).slice().sort(voucherSort), [items, detail]);

  const toggle = (id: string) => setSelectedIds((current) => { const next = new Set(current); next.has(id) ? next.delete(id) : next.add(id); return next; });
  const toggleAll = () => setSelectedIds((current) => { const next = new Set(current); visible.forEach((x) => allVisibleSelected ? next.delete(x.id) : next.add(x.id)); return next; });
  const update = (id: string, patch: Partial<VoucherCustomer>) => setItems((rows) => rows.map((item) => { if (item.id !== id) return item; const next = { ...item, ...patch, updatedAt: new Date().toISOString() }; persist(next); return next; }));
  const applyBulk = async () => {
    if (!selected.length) return; setBatchSaving(true);
    const changes = new Map(selected.map((item) => [item.id, { ...item, [batchItem]: batchStatus === "done" ? { done: true, handler: batchHandler } : { done: false, handler: null }, updatedAt: new Date().toISOString() }]));
    const responses = await Promise.all([...changes.values()].map((item) => fetch("/api/vouchers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(item) })));
    if (responses.some((response) => !response.ok)) notify("批次儲存失敗，請重新整理後再試");
    else { setItems((rows) => rows.map((item) => changes.get(item.id) ?? item)); setSelectedIds(new Set()); setShowBatch(false); notify(`已批次更新 ${selected.length} 家客戶`); }
    setBatchSaving(false);
  };
  const importFile = async (file: File) => {
    try {
      const workbook = XLSX.read(await file.arrayBuffer());
      const matrix = XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets[workbook.SheetNames[0]], { header: 1, raw: true, defval: "" });
      const base = parseImportedSheet(matrix);
      const imported = base.map((item) => ({ id: item.id, code: item.code, title: item.title, owner: item.owner, registeredDate: item.registeredDate, inspect: normalizeStep(false), extra: normalizeStep(false), journal: normalizeStep(false), bind: normalizeStep(false), restore: normalizeStep(false), updatedAt: item.updatedAt }));
      const response = await fetch("/api/vouchers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(imported) });
      if (!response.ok) throw new Error(); setItems(imported); setSelectedIds(new Set()); resetFilters(); notify(`已匯入 ${imported.length} 家客戶`);
    } catch { notify("匯入失敗：請確認 Excel 包含「客編」與「抬頭」欄位"); }
  };
  const exportFile = (rows = items, name = "切傳票進度") => { const sheet = XLSX.utils.json_to_sheet(rows.map(voucherExportRow)); const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, name.slice(0, 31)); XLSX.writeFile(book, `${name}_${today()}.xlsx`); notify("最新進度已匯出"); };
  const backupPayload = () => JSON.stringify({ version: 1, type: "voucher-progress", savedAt: new Date().toISOString(), customers: items }, null, 2);
  const writeBackup = async (handle: any, quiet = false) => { const permission = await handle.queryPermission?.({ mode: "readwrite" }); if (permission !== "granted" && await handle.requestPermission?.({ mode: "readwrite" }) !== "granted") throw new Error(); const writable = await handle.createWritable(); await writable.write(backupPayload()); await writable.close(); localStorage.setItem("voucher-progress-last-auto-backup", today()); if (!quiet) notify(`已儲存 ${items.length} 家客戶的 JSON 備份`); };
  const saveJson = async () => { try { let handle = backupHandle.current || await backupSetting<any>("get", undefined, "voucher-backup"); const picker = (window as any).showSaveFilePicker; if (!handle && picker) { handle = await picker({ suggestedName: "切傳票進度備份.json", types: [{ description: "JSON 備份", accept: { "application/json": [".json"] } }] }); await backupSetting("put", handle, "voucher-backup"); } if (!handle) { const link = document.createElement("a"); link.href = URL.createObjectURL(new Blob([backupPayload()], { type: "application/json" })); link.download = "切傳票進度備份.json"; link.click(); URL.revokeObjectURL(link.href); return notify("已下載 JSON 備份"); } backupHandle.current = handle; await writeBackup(handle); } catch (error: any) { if (error?.name !== "AbortError") notify("無法儲存，請重新選擇 JSON 檔案位置"); } };
  useEffect(() => { if (!loaded || !items.length || localStorage.getItem("voucher-progress-last-auto-backup") === today()) return; backupSetting<any>("get", undefined, "voucher-backup").then(async (handle) => { if (!handle || await handle.queryPermission?.({ mode: "readwrite" }) !== "granted") return; backupHandle.current = handle; await writeBackup(handle, true); notify("今日切傳票 JSON 備份已自動儲存"); }).catch(() => undefined); }, [loaded, items]);
  const readBackup = async (file: File) => { try { const data = JSON.parse(await file.text()); const rows = (Array.isArray(data) ? data : data.customers) as Record<string, unknown>[]; const restored = rows.map((raw) => ({ ...normalizeVoucher(raw), id: textValue(raw.id) || crypto.randomUUID(), code: textValue(raw.code ?? raw["客編"]), title: textValue(raw.title ?? raw["抬頭"]), owner: textValue(raw.owner ?? raw["負責人"]), registeredDate: excelDate(raw.registeredDate ?? raw["登記日期"]), updatedAt: textValue(raw.updatedAt) || new Date().toISOString() })).filter((x) => x.code && x.title); if (!restored.length) throw new Error(); setPendingRestore(restored); } catch { notify("還原失敗：請選擇切傳票追蹤匯出的 JSON 備份檔"); } };

  return <main className="voucher-tracker">
    {toast && <div className="toast"><CircleCheck size={17}/>{toast}</div>}
    <header className="topbar"><div className="brand"><div className="brand-mark voucher-mark"><BookOpenCheck size={21}/></div><div><h1>切傳票追蹤</h1><p>傳票作業進度管理</p></div></div><div className="actions">
      <input ref={fileInput} type="file" accept=".xlsx,.xls,.csv" hidden onChange={(e) => { const file = e.target.files?.[0]; if (file) importFile(file); e.target.value = ""; }}/><input ref={restoreInput} type="file" accept=".json" hidden onChange={(e) => { const file = e.target.files?.[0]; if (file) readBackup(file); e.target.value = ""; }}/>
      <button className="button secondary" onClick={onBack}><ArrowLeft size={16}/>返回入口</button><button className="button secondary" onClick={() => fileInput.current?.click()}><Upload size={16}/>匯入 Excel</button><button className="button secondary" onClick={() => restoreInput.current?.click()}><Upload size={16}/>JSON 還原</button><button className="button secondary" onClick={() => exportFile()}><Download size={16}/>匯出進度</button><button className="button primary save-button" onClick={saveJson}><Save size={16}/>儲存</button><button className="button destructive" disabled={!items.length} onClick={() => setShowClearAll(true)}><Trash2 size={16}/>清除所有資料</button><button className="button primary" onClick={() => { setForm({ code:"", title:"", owner:"" }); setShowAdd(true); }}><Plus size={16}/>新增客戶</button><button className="button secondary logout-button" onClick={onLogout}><LogOut size={16}/>登出</button>
    </div></header>
    <section className="page-shell voucher-page-shell"><div className="welcome"><div><p className="eyebrow voucher-eyebrow">切傳票作業進度</p><h2>每一步都能指定經手人</h2><p>電腦版完整顯示五個作業欄位，兩套資料分開保存。</p></div><div className="period"><span>共用狀態</span><strong>團隊資料已同步</strong></div></div>
      <section className="stats-grid"><div className="stats-row voucher-summary-row"><StatCard label="總客戶數" value={stats.total} tone="blue" icon={<Users size={20}/>} onClick={() => setDetail("總客戶數")}/><StatCard label="已完成數" value={stats.done} tone="green" icon={<CircleCheck size={20}/>} onClick={() => setDetail("已完成數")}/></div><div className="stats-row stats-row-five">{VOUCHER_KEYS.map((key, index) => <StatCard key={key} label={`已${VOUCHER_LABELS[key]}`} value={stats[key]} tone={["orange","purple","sky","teal","green"][index]} icon={<Check size={20}/>} onClick={() => setDetail(key)}/>)}</div></section>
      <section className="workspace"><div className="workspace-heading"><div><h3>客戶處理進度</h3><p>{items.length ? `目前顯示 ${visible.length} 家／共 ${items.length} 家` : "尚未建立客戶"}</p></div><div className="legend"><span><i className="dot done"/>已完成</span><span><i className="dot waiting"/>尚未完成</span></div></div><div className="filters"><label className="search-box"><Search size={17}/><input placeholder="搜尋客編；多家可用空格分開…" value={search} onChange={(e) => setSearch(e.target.value)}/>{search && <button type="button" className="search-clear" onClick={() => setSearch("")}><X size={15}/></button>}</label><label className="select-box"><Filter size={16}/><select value={codeGroupFilter} onChange={(e) => setCodeGroupFilter(e.target.value)}><option>{ALL_CODE_GROUPS}</option>{CODE_GROUPS.map((x) => <option key={x}>{x}</option>)}</select><ChevronDown size={15}/></label><label className="select-box"><Users size={16}/><select value={owner} onChange={(e) => setOwner(e.target.value)}><option>{ALL_OWNERS}</option>{owners.map((x) => <option key={x}>{x}</option>)}</select><ChevronDown size={15}/></label><label className="select-box"><Filter size={16}/><select value={stageFilter} onChange={(e) => setStageFilter(e.target.value)}><option>{ALL_STAGES}</option><option>待檢查</option><option>待算另計</option><option>待切傳票</option><option>待裝訂傳票</option><option>待歸位</option><option>已完成</option></select><ChevronDown size={15}/></label><button className="button batch-fixed" disabled={!selected.length} onClick={() => setShowBatch(true)}><Check size={15}/>批次處理{selected.length ? `（${selected.length}）` : ""}</button></div>
      {!items.length ? <div className="empty"><div className="empty-icon"><BookOpenCheck size={25}/></div><strong>目前還沒有客戶資料</strong><p>按「新增客戶」自行輸入，或從 Excel 匯入。</p><button className="button primary" onClick={() => setShowAdd(true)}><Plus size={15}/>新增第一位客戶</button></div> : !visible.length ? <div className="empty"><strong>找不到符合條件的客戶</strong><p>請調整搜尋或篩選條件。</p><button className="button secondary" onClick={resetFilters}>清除篩選</button></div> : <div className="table-wrap"><table className="voucher-table"><thead><tr><th className="select-column"><input type="checkbox" checked={allVisibleSelected} onChange={toggleAll}/></th><th>客編</th><th>抬頭</th><th>負責人</th>{VOUCHER_KEYS.map((key) => <th key={key}>{VOUCHER_LABELS[key]}</th>)}<th>目前階段</th><th>操作</th></tr></thead><tbody>{visible.map((item) => <tr key={item.id} className={selectedIds.has(item.id) ? "selected-row" : ""}><td className="select-column"><input type="checkbox" checked={selectedIds.has(item.id)} onChange={() => toggle(item.id)}/></td><td className="code">{item.code}</td><td className="title-cell">{item.title}</td><td><input className="inline-field owner-field" value={item.owner} onChange={(e) => update(item.id,{owner:e.target.value})}/></td>{VOUCHER_KEYS.map((key) => <td key={key}><StepButton step={item[key]} label={VOUCHER_LABELS[key]} onClick={() => setEditing({item,key})}/></td>)}<td><span className="stage">{voucherStage(item)}</span></td><td><button className="icon-button danger" onClick={() => setDeleting(item)}><Trash2 size={16}/></button></td></tr>)}</tbody></table></div>}</section><div className="privacy-note"><Info size={15}/>切傳票資料為團隊共用，並與營業稅資料分開保存。</div></section>
    {showAdd && <div className="modal-backdrop" onMouseDown={() => setShowAdd(false)}><div className="modal" onMouseDown={(e) => e.stopPropagation()}><div className="modal-head"><div><h3>新增客戶</h3><p>建立一筆新的切傳票進度資料</p></div><button className="icon-button" onClick={() => setShowAdd(false)}><X size={19}/></button></div><form onSubmit={(e) => { e.preventDefault(); if (!form.code.trim() || !form.title.trim() || !form.owner.trim()) return; if (items.some((x) => x.code.toLowerCase() === form.code.trim().toLowerCase())) return notify("此客編已存在"); const item: VoucherCustomer = { id:crypto.randomUUID(), code:form.code.trim(), title:form.title.trim(), owner:form.owner.trim(), registeredDate:"", inspect:normalizeStep(false), extra:normalizeStep(false), journal:normalizeStep(false), bind:normalizeStep(false), restore:normalizeStep(false), updatedAt:new Date().toISOString() }; setItems((rows) => [item,...rows]); persist(item); setShowAdd(false); notify(`已新增 ${item.title}`); }}><div className="form-grid voucher-add-form"><label>客編<span>*</span><input value={form.code} onChange={(e) => setForm({...form,code:e.target.value})} required autoFocus/></label><label>抬頭<span>*</span><input value={form.title} onChange={(e) => setForm({...form,title:e.target.value})} required/></label><label>負責人<span>*</span><input value={form.owner} onChange={(e) => setForm({...form,owner:e.target.value})} required/></label></div><div className="modal-actions"><button type="button" className="button secondary" onClick={() => setShowAdd(false)}>取消</button><button className="button primary">新增客戶</button></div></form></div></div>}
    {editing && <div className="modal-backdrop" onMouseDown={() => setEditing(null)}><div className="modal small" onMouseDown={(e) => e.stopPropagation()}><div className="modal-head"><div><h3>{VOUCHER_LABELS[editing.key]}經手人</h3><p>請選擇這一步是誰做的。</p></div><button className="icon-button" onClick={() => setEditing(null)}><X size={19}/></button></div><div className="handler-options">{HANDLERS.map((handler) => <button key={handler} className={`handler-option ${editing.item[editing.key].handler === handler ? "selected" : ""}`} onClick={() => { update(editing.item.id,{[editing.key]:{done:true,handler}}); setEditing(null); }}>{handler}</button>)}</div><div className="modal-actions"><button className="button secondary" onClick={() => setEditing(null)}>關閉</button>{editing.item[editing.key].done && <button className="button destructive" onClick={() => { update(editing.item.id,{[editing.key]:{done:false,handler:null}}); setEditing(null); }}>取消完成</button>}</div></div></div>}
    {showBatch && <div className="modal-backdrop" onMouseDown={() => setShowBatch(false)}><div className="modal small" onMouseDown={(e) => e.stopPropagation()}><div className="modal-head"><div><h3>批次處理</h3><p>將設定套用到已選取的 {selected.length} 家客戶。</p></div><button className="icon-button" onClick={() => setShowBatch(false)}><X size={19}/></button></div><div className="batch-form batch-selects"><label>工作項目<select value={batchItem} onChange={(e) => setBatchItem(e.target.value as VoucherKey)}>{VOUCHER_KEYS.map((key) => <option key={key} value={key}>{VOUCHER_LABELS[key]}</option>)}</select></label><label>設定狀態<select value={batchStatus} onChange={(e) => setBatchStatus(e.target.value as "done"|"cancel")}><option value="done">完成</option><option value="cancel">取消完成</option></select></label>{batchStatus === "done" && <label>經手人<select value={batchHandler} onChange={(e) => setBatchHandler(e.target.value)}>{HANDLERS.map((x) => <option key={x}>{x}</option>)}</select></label>}</div><div className="modal-actions"><button className="button secondary" onClick={() => setShowBatch(false)}>關閉</button><button className="button primary" disabled={batchSaving} onClick={applyBulk}>套用設定</button></div></div></div>}
    {deleting && <div className="modal-backdrop"><div className="modal small"><div className="modal-head"><div><h3>刪除客戶</h3><p>確定要刪除「{deleting.title}」嗎？</p></div></div><div className="modal-actions"><button className="button secondary" onClick={() => setDeleting(null)}>取消</button><button className="button destructive" onClick={async () => { await fetch("/api/vouchers",{method:"DELETE",headers:{"Content-Type":"application/json"},body:JSON.stringify({id:deleting.id})}); setItems((rows) => rows.filter((x) => x.id !== deleting.id)); setDeleting(null); notify("客戶已刪除"); }}>確認刪除</button></div></div></div>}
    {showClearAll && <div className="modal-backdrop"><div className="modal small"><div className="modal-head"><div><h3>確認清除嗎？</h3><p>將清除全部 {items.length} 家切傳票資料，請先確認已有備份。</p></div></div><div className="modal-actions"><button className="button secondary" onClick={() => setShowClearAll(false)}>取消</button><button className="button destructive" onClick={async () => { const response = await fetch("/api/vouchers",{method:"PUT",headers:{"Content-Type":"application/json"},body:"[]"}); if (response.ok) { setItems([]); setSelectedIds(new Set()); setShowClearAll(false); notify("所有切傳票資料已清除"); } }}>確認清除</button></div></div></div>}
    {pendingRestore && <div className="modal-backdrop"><div className="modal small"><div className="modal-head"><div><h3>從 JSON 備份還原</h3><p>將以備份中的 {pendingRestore.length} 家客戶覆蓋目前資料。</p></div></div><div className="modal-actions"><button className="button secondary" onClick={() => setPendingRestore(null)}>取消</button><button className="button primary" onClick={async () => { const response = await fetch("/api/vouchers",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify(pendingRestore)}); if (response.ok) { setItems(pendingRestore); setPendingRestore(null); notify("切傳票資料已還原"); } }}>確認還原</button></div></div></div>}
    {detail && <div className="modal-backdrop" onMouseDown={() => setDetail(null)}><div className="modal detail-modal" onMouseDown={(e) => e.stopPropagation()}><div className="modal-head"><div><h3>{VOUCHER_KEYS.includes(detail as VoucherKey) ? `已${VOUCHER_LABELS[detail as VoucherKey]}` : detail}明細</h3><p>共 {detailItems.length} 家客戶</p></div><button className="icon-button" onClick={() => setDetail(null)}><X size={19}/></button></div><div className="detail-list">{detailItems.map((item) => <div className="detail-row" key={item.id}><div><strong>{item.title}</strong><span>{item.code}</span></div><div><span>{item.owner || "未填負責人"}</span></div><span className="stage">{voucherStage(item)}</span></div>)}</div><div className="modal-actions"><button className="button secondary" onClick={() => setDetail(null)}>關閉</button><button className="button primary" disabled={!detailItems.length} onClick={() => exportFile(detailItems,"切傳票明細")}><Download size={15}/>匯出 Excel</button></div></div></div>}
  </main>;
}

export default function App() {
  const [authStatus, setAuthStatus] = useState<"checking" | "signed-out" | "signed-in">("checking");
  const [workspaceMode, setWorkspaceMode] = useState<"portal" | "tax" | "voucher">("portal");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [loginBusy, setLoginBusy] = useState(false);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [portalVouchers, setPortalVouchers] = useState<VoucherCustomer[]>([]);
  const [showUnreceived, setShowUnreceived] = useState(false);
  const [showRecent, setShowRecent] = useState(false);
  const [unreceivedSearch, setUnreceivedSearch] = useState("");
  const [loaded, setLoaded] = useState(false);
  const [search, setSearch] = useState("");
  const [owner, setOwner] = useState(ALL_OWNERS);
  const [stageFilter, setStageFilter] = useState(ALL_STAGES);
  const [codeGroupFilter, setCodeGroupFilter] = useState(ALL_CODE_GROUPS);
  const [toast, setToast] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [showClearAll, setShowClearAll] = useState(false);
  const [pendingRestore, setPendingRestore] = useState<Customer[] | null>(null);
  const [deleting, setDeleting] = useState<Customer | null>(null);
  const [detailStage, setDetailStage] = useState<string | null>(null);
  const [editingStep, setEditingStep] = useState<{ customer: Customer; key: StepKey } | null>(null);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showBatch, setShowBatch] = useState(false);
  const [batchItem, setBatchItem] = useState<StepKey | "date">("sort");
  const [batchStatus, setBatchStatus] = useState<"done" | "cancel">("done");
  const [batchHandler, setBatchHandler] = useState(HANDLERS[0]);
  const [batchDate, setBatchDate] = useState(today());
  const [batchSaving, setBatchSaving] = useState(false);
  const [form, setForm] = useState({ code: "", title: "", owner: "", registeredDate: today() });
  const fileInput = useRef<HTMLInputElement>(null);
  const restoreInput = useRef<HTMLInputElement>(null);
  const backupHandle = useRef<any>(null);

  useEffect(() => {
    fetch("/api/auth/session", { cache: "no-store" })
      .then((response) => response.json())
      .then((result: { authenticated?: boolean }) => setAuthStatus(result.authenticated ? "signed-in" : "signed-out"))
      .catch(() => setAuthStatus("signed-out"));
  }, []);

  useEffect(() => {
    if (authStatus !== "signed-in") return;
    let active = true;
    const loadShared = async () => {
      try {
        const [response, voucherResponse] = await Promise.all([
          fetch("/api/customers", { cache: "no-store" }),
          fetch("/api/vouchers", { cache: "no-store" }),
        ]);
        if (response.status === 401) { setAuthStatus("signed-out"); throw new Error("unauthorized"); }
        if (!response.ok) throw new Error("load");
        let shared = (await response.json() as Record<string, unknown>[]).map(normalizeCustomer);
        if (!shared.length) {
          try {
            const local = (JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]") as Record<string, unknown>[]).map(normalizeCustomer);
            if (local.length) {
              await fetch("/api/customers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(local) });
              shared = local;
              localStorage.removeItem(STORAGE_KEY);
            }
          } catch { /* no local data to migrate */ }
        }
        const vouchers = voucherResponse.ok ? (await voucherResponse.json() as Record<string, unknown>[]).map(normalizeVoucher) : [];
        if (active) { setCustomers(shared); setPortalVouchers(vouchers); setLoaded(true); }
      } catch { if (active) { setLoaded(true); notify("共用資料載入失敗，請重新整理再試"); } }
    };
    loadShared();
    const timer = window.setInterval(loadShared, 10000);
    return () => { active = false; window.clearInterval(timer); };
  }, [authStatus]);

  const login = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoginBusy(true); setLoginError("");
    try {
      const response = await fetch("/api/auth/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ password: loginPassword }) });
      if (!response.ok) { setLoginError("密碼錯誤，請重新輸入"); return; }
      setLoginPassword(""); setLoaded(false); setAuthStatus("signed-in");
    } catch { setLoginError("目前無法登入，請稍後再試"); }
    finally { setLoginBusy(false); }
  };

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setCustomers([]); setPortalVouchers([]); setSelectedIds(new Set()); setLoaded(false); setWorkspaceMode("portal"); setAuthStatus("signed-out");
  };

  const writeJsonBackup = async (handle: any, quiet = false) => {
    const permission = await handle.queryPermission?.({ mode: "readwrite" });
    if (permission !== "granted") {
      const requested = await handle.requestPermission?.({ mode: "readwrite" });
      if (requested !== "granted") throw new Error("permission");
    }
    const writable = await handle.createWritable();
    await writable.write(JSON.stringify({ version: 13, savedAt: new Date().toISOString(), customers }, null, 2));
    await writable.close();
    localStorage.setItem("invoice-progress-last-auto-backup", today());
    if (!quiet) notify(`已儲存 ${customers.length} 家客戶的 JSON 備份`);
  };
  const saveJson = async () => {
    try {
      let handle = backupHandle.current || await backupSetting<any>("get");
      if (!handle) {
        const picker = (window as any).showSaveFilePicker;
        if (!picker) {
          const blob = new Blob([JSON.stringify({ version: 13, savedAt: new Date().toISOString(), customers }, null, 2)], { type: "application/json" });
          const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = `發票進度備份.json`; link.click(); URL.revokeObjectURL(link.href);
          return notify("已下載 JSON；此瀏覽器不支援記住儲存位置");
        }
        handle = await picker({ suggestedName: "發票進度備份.json", types: [{ description: "JSON 備份", accept: { "application/json": [".json"] } }] });
        await backupSetting("put", handle);
      }
      backupHandle.current = handle;
      await writeJsonBackup(handle);
    } catch (error: any) {
      if (error?.name !== "AbortError") notify("無法儲存，請重新選擇 JSON 檔案位置");
    }
  };

  useEffect(() => {
    if (!loaded || !customers.length || localStorage.getItem("invoice-progress-last-auto-backup") === today()) return;
    backupSetting<any>("get").then(async (handle) => {
      if (!handle || await handle.queryPermission?.({ mode: "readwrite" }) !== "granted") return;
      backupHandle.current = handle;
      try { await writeJsonBackup(handle, true); notify("今日 JSON 備份已自動儲存"); } catch { /* manual save can renew permission */ }
    }).catch(() => undefined);
  }, [loaded, customers]);
  const saveCustomer = async (customer: Customer) => {
    const response = await fetch("/api/customers", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(customer) });
    if (!response.ok) notify("儲存失敗，請重新整理後再試");
  };

  const owners = useMemo(() => Array.from(new Set(customers.map((item) => item.owner).filter(Boolean))).sort(), [customers]);
  const visible = useMemo(() => {
    const terms = search.trim().toLowerCase().split(/[\s,，、;；]+/).filter(Boolean);
    const isMultiSearch = terms.length > 1;
    return customers.filter((item) => (!terms.length || terms.some((term) => isMultiSearch
      ? item.code.trim().toLowerCase() === term
      : item.code.toLowerCase().includes(term) || item.title.toLowerCase().includes(term)))
      && (owner === ALL_OWNERS || item.owner === owner) && (stageFilter === ALL_STAGES || stage(item) === stageFilter)
      && (codeGroupFilter === ALL_CODE_GROUPS || codeGroup(item.code) === codeGroupFilter)).sort(sortByCode);
  }, [customers, search, owner, stageFilter, codeGroupFilter]);
  const stats = useMemo(() => ({
    total: customers.length,
    undated: customers.filter((item) => !item.registeredDate.trim()).length,
    registered: customers.filter((item) => item.registeredDate.trim()).length,
    sorted: customers.filter((item) => item.sort.done).length,
    keyed: customers.filter((item) => item.keyin.done).length,
    checked: customers.filter((item) => item.check.done).length,
    uploaded: customers.filter((item) => item.upload.done).length,
    done: customers.filter((item) => item.sort.done && item.keyin.done && item.check.done && item.upload.done).length,
  }), [customers]);
  const detailCustomers = useMemo(() => (detailStage === "總客戶數" ? customers : detailStage === "尚未登記" ? customers.filter((item) => !item.registeredDate.trim()) : detailStage === "已登記數" ? customers.filter((item) => item.registeredDate.trim()) : detailStage === "已完成數" ? customers.filter((item) => item.sort.done && item.keyin.done && item.check.done && item.upload.done) : detailStage === "已整理" ? customers.filter((item) => item.sort.done) : detailStage === "已 Key in" ? customers.filter((item) => item.keyin.done) : detailStage === "已檢查" ? customers.filter((item) => item.check.done) : detailStage === "已上傳" ? customers.filter((item) => item.upload.done) : customers.filter((item) => stage(item) === detailStage)).slice().sort(sortByCode), [customers, detailStage]);
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(""), 2800); };
  const resetFilters = () => { setSearch(""); setOwner(ALL_OWNERS); setStageFilter(ALL_STAGES); setCodeGroupFilter(ALL_CODE_GROUPS); };
  const selectedCustomers = useMemo(() => customers.filter((item) => selectedIds.has(item.id)), [customers, selectedIds]);
  const allVisibleSelected = visible.length > 0 && visible.every((item) => selectedIds.has(item.id));
  const toggleSelected = (id: string) => setSelectedIds((current) => {
    const next = new Set(current);
    if (next.has(id)) next.delete(id); else next.add(id);
    return next;
  });
  const toggleAllVisible = () => setSelectedIds((current) => {
    const next = new Set(current);
    if (allVisibleSelected) visible.forEach((item) => next.delete(item.id));
    else visible.forEach((item) => next.add(item.id));
    return next;
  });
  const applyBulk = async (transform: (customer: Customer) => Customer, message: string) => {
    if (!selectedCustomers.length) return;
    setBatchSaving(true);
    const replacements = new Map(selectedCustomers.map((item) => {
      const next = transform(item);
      return [item.id, { ...next, updatedAt: new Date().toISOString() }];
    }));
    const responses = await Promise.all([...replacements.values()].map((item) => fetch("/api/customers", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(item),
    })));
    if (responses.some((response) => !response.ok)) {
      notify("批次儲存失敗，請重新整理後再試");
    } else {
      setCustomers((items) => items.map((item) => replacements.get(item.id) ?? item));
      setSelectedIds(new Set());
      setShowBatch(false);
      notify(message);
    }
    setBatchSaving(false);
  };

  const importFile = async (file: File) => {
    try {
      const workbook = XLSX.read(await file.arrayBuffer());
      const matrix = XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets[workbook.SheetNames[0]], { header: 1, raw: true, defval: "" });
      const imported = parseImportedSheet(matrix);
      if (!imported.length) throw new Error("empty");
      const response = await fetch("/api/customers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(imported) });
      if (!response.ok) throw new Error("save");
      setCustomers(imported); setSelectedIds(new Set()); resetFilters(); notify(`已匯入 ${imported.length} 家客戶，所有同事都會看到`);
    } catch (error) {
      notify(error instanceof Error && error.message === "missing-required-columns"
        ? "匯入失敗：請確認 Excel 至少包含「客編」與「抬頭」兩個欄位"
        : "無法讀取檔案，請確認每筆資料都有客編與抬頭");
    }
  };
  const parseBackupCustomer = (value: Record<string, unknown>): Customer => {
    const now = new Date().toISOString();
    const stepFromBackup = (raw: unknown, label: string): Step => {
      if (raw && typeof raw === "object") return normalizeStep(raw);
      const text = textValue(raw);
      const done = Boolean(text) && !text.startsWith("＋") && !text.includes("未完成");
      const handler = done ? text.replace(label, "").replace(/[：:]/g, "").trim() || null : null;
      return { done, handler };
    };
    return {
      id: textValue(value.id) || crypto.randomUUID(),
      code: textValue(value.code ?? value["客編"]),
      title: textValue(value.title ?? value["抬頭"]),
      owner: textValue(value.owner ?? value["負責人"]),
      registeredDate: excelDate(value.registeredDate ?? value["登記日期"]),
      sort: stepFromBackup(value.sort ?? value.sorted ?? value["整理"], "整理"),
      keyin: stepFromBackup(value.keyin ?? value.keyed ?? value["KeyIn"] ?? value["Key in"], "Key in"),
      check: stepFromBackup(value.check ?? value.checked ?? value["檢查"], "檢查"),
      upload: stepFromBackup(value.upload ?? value.uploaded ?? value["上傳"], "上傳"),
      updatedAt: textValue(value.updatedAt) || now,
    };
  };
  const readBackupFile = async (file: File) => {
    try {
      const parsed = JSON.parse(await file.text()) as unknown;
      const rawRows = Array.isArray(parsed)
        ? parsed
        : parsed && typeof parsed === "object" && Array.isArray((parsed as { customers?: unknown[] }).customers)
          ? (parsed as { customers: unknown[] }).customers
          : null;
      if (!rawRows?.length) throw new Error("empty");
      const restored = rawRows
        .filter((row): row is Record<string, unknown> => Boolean(row) && typeof row === "object")
        .map(parseBackupCustomer)
        .filter((customer) => customer.code && customer.title);
      if (!restored.length) throw new Error("invalid");
      setPendingRestore(Array.from(new Map(restored.map((customer) => [customer.code.toLowerCase(), customer])).values()));
    } catch {
      notify("還原失敗：請選擇本系統匯出的 JSON 備份檔");
    }
  };
  const restoreBackup = async () => {
    if (!pendingRestore) return;
    const response = await fetch("/api/customers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify(pendingRestore) });
    if (!response.ok) return notify("還原失敗：資料未被變更，請稍後再試");
    setCustomers(pendingRestore); setSelectedIds(new Set()); resetFilters();
    const count = pendingRestore.length; setPendingRestore(null);
    notify(`已從 JSON 備份還原 ${count} 家客戶`);
  };
  const clearAllCustomers = async () => {
    const response = await fetch("/api/customers", { method: "PUT", headers: { "Content-Type": "application/json" }, body: "[]" });
    if (!response.ok) return notify("清除失敗：資料未被變更，請稍後再試");
    setCustomers([]); setSelectedIds(new Set()); resetFilters(); setShowClearAll(false);
    notify("所有客戶資料已清除");
  };
  const exportFile = () => {
    const rows = customers.map((item) => exportRow(item));
    const sheet = XLSX.utils.json_to_sheet(rows); sheet["!cols"] = [{wch:12},{wch:28},{wch:12},{wch:14},{wch:10},{wch:10},{wch:10},{wch:12},{wch:22}];
    const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, "發票進度"); XLSX.writeFile(book, `發票進度_${today()}.xlsx`); notify("最新進度已匯出");
  };
  const exportDetail = () => {
    if (!detailStage || !detailCustomers.length) return;
    const rows = detailCustomers.map((item) => exportRow(item));
    const sheet = XLSX.utils.json_to_sheet(rows);
    sheet["!cols"] = [{wch:12},{wch:28},{wch:12},{wch:14},{wch:10},{wch:10},{wch:10},{wch:12},{wch:22}];
    const book = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(book, sheet, detailStage.slice(0, 31));
    XLSX.writeFile(book, `${detailStage}明細_${today()}.xlsx`);
    notify(`已匯出${detailStage}明細`);
  };
  const addCustomer = (event: React.FormEvent) => {
    event.preventDefault(); const code = form.code.trim(), title = form.title.trim(), person = form.owner.trim();
    if (!code || !title || !person || !form.registeredDate) return;
    if (customers.some((item) => item.code.toLowerCase() === code.toLowerCase())) return notify("此客編已存在，請使用不同客編");
    const customer: Customer = { id: crypto.randomUUID(), code, title, owner: person, registeredDate: form.registeredDate, sort: normalizeStep(false), keyin: normalizeStep(false), check: normalizeStep(false), upload: normalizeStep(false), updatedAt: new Date().toISOString() };
    setCustomers((items) => [customer, ...items]); saveCustomer(customer);
    setShowAdd(false); notify(`已新增 ${title}`);
  };
  const setStep = (handler: string | null) => {
    if (!editingStep) return;
    setCustomers((items) => items.map((item) => {
      if (item.id !== editingStep.customer.id) return item;
      const next = { ...item, [editingStep.key]: { done: Boolean(handler), handler }, updatedAt: new Date().toISOString() };
      saveCustomer(next); return next;
    }));
    setEditingStep(null);
  };
  const updateCustomer = (id: string, patch: Partial<Pick<Customer, "owner" | "registeredDate">>) => setCustomers((items) => items.map((item) => {
    if (item.id !== id) return item;
    const next = { ...item, ...patch, updatedAt: new Date().toISOString() };
    saveCustomer(next);
    return next;
  }));

  const taxCompletedCustomers = customers.filter((item) => item.sort.done && item.keyin.done && item.check.done && item.upload.done).length;
  const taxTotalCustomers = customers.length;
  const voucherCompletedCustomers = portalVouchers.filter((item) => VOUCHER_KEYS.every((key) => item[key].done)).length;
  const voucherTotalCustomers = portalVouchers.length;
  const taxPercent = taxTotalCustomers ? Math.round(taxCompletedCustomers / taxTotalCustomers * 100) : 0;
  const voucherPercent = voucherTotalCustomers ? Math.round(voucherCompletedCustomers / voucherTotalCustomers * 100) : 0;
  const unreceived = customers.filter((item) => !item.registeredDate.trim()).sort(sortByCode);
  const visibleUnreceived = unreceived.filter((item) => {
    const term = unreceivedSearch.trim().toLowerCase();
    return !term || item.code.toLowerCase().includes(term) || item.title.toLowerCase().includes(term);
  });
  const latestTaxAction = (item: Customer) => {
    const latest = (["upload", "check", "keyin", "sort"] as StepKey[]).find((key) => item[key].done);
    return latest ? { text: `完成${STEP_LABELS[latest]}`, handler: item[latest].handler || item.owner || "未指定" } : item.registeredDate ? { text: "設定登記日期", handler: item.owner || "未指定" } : { text: "更新客戶資料", handler: item.owner || "未指定" };
  };
  const latestVoucherAction = (item: VoucherCustomer) => {
    const latest = [...VOUCHER_KEYS].reverse().find((key) => item[key].done);
    return latest ? { text: `完成${VOUCHER_LABELS[latest]}`, handler: item[latest].handler || item.owner || "未指定" } : { text: "更新客戶資料", handler: item.owner || "未指定" };
  };
  const recentUpdates = [...customers.map((item) => ({ id: `tax-${item.id}`, code: item.code, title: item.title, updatedAt: item.updatedAt, module: "營業稅", ...latestTaxAction(item) })), ...portalVouchers.map((item) => ({ id: `voucher-${item.id}`, code: item.code, title: item.title, updatedAt: item.updatedAt, module: "切傳票", ...latestVoucherAction(item) }))]
    .filter((item) => !Number.isNaN(Date.parse(item.updatedAt))).sort((a, b) => Date.parse(b.updatedAt) - Date.parse(a.updatedAt)).slice(0, 5);
  const formatRecentTime = (value: string) => {
    const date = new Date(value), now = new Date();
    const sameDay = date.toDateString() === now.toDateString();
    const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
    const prefix = sameDay ? "今天" : date.toDateString() === yesterday.toDateString() ? "昨天" : `${date.getMonth() + 1}/${date.getDate()}`;
    return `${prefix} ${date.toLocaleTimeString("zh-TW", { hour: "2-digit", minute: "2-digit", hour12: false })}`;
  };
  const exportUnreceived = () => {
    const sheet = XLSX.utils.json_to_sheet(unreceived.map((item) => ({ 客編: item.code, 客戶名稱: item.title, 負責人: item.owner, 最後更新時間: new Date(item.updatedAt).toLocaleString("zh-TW") })));
    const book = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(book, sheet, "未收到資料"); XLSX.writeFile(book, `未收到資料明細_${today()}.xlsx`);
  };

  if (authStatus === "checking") return <main className="auth-screen"><div className="auth-card auth-loading"><div className="auth-mark"><LockKeyhole size={27}/></div><p>正在確認登入狀態…</p></div></main>;
  if (authStatus === "signed-out") return <main className="auth-screen"><form className="auth-card" onSubmit={login}><div className="auth-mark"><LockKeyhole size={29}/></div><p className="auth-eyebrow">內部工作系統</p><h1>發票進度追蹤</h1><p className="auth-description">請輸入共用密碼後繼續</p><label className="auth-label">密碼<input type="password" value={loginPassword} onChange={(event) => { setLoginPassword(event.target.value); setLoginError(""); }} placeholder="請輸入密碼" autoFocus autoComplete="current-password" required/></label>{loginError && <p className="auth-error" role="alert">{loginError}</p>}<button className="button primary auth-submit" disabled={loginBusy || !loginPassword}>{loginBusy ? "登入中…" : "登入"}</button><p className="auth-note">僅供授權同事使用，請勿將密碼轉傳給無關人員。</p></form></main>;
  if (workspaceMode === "portal") return <main className="portal-screen"><header className="portal-header"><div className="brand"><div className="brand-mark"><Home size={21}/></div><div><h1>作業進度追蹤</h1><p>請選擇要查看的作業模組</p></div></div><button className="button secondary logout-button" onClick={logout}><LogOut size={16}/>登出</button></header><section className="portal-content portal-dashboard"><div className="portal-title"><h2>作業進度追蹤</h2><p>請選擇要查看的作業模組</p></div><div className="module-grid progress-module-grid"><article className="progress-module tax-progress"><h3>營業稅追蹤</h3><div className="progress-numbers"><strong>{taxCompletedCustomers} / {taxTotalCustomers} 家</strong><span>已完成</span><i/><b>完成率 {taxPercent}%</b></div><div className="progress-track" aria-label={`營業稅完成率 ${taxPercent}%`}><span style={{width:`${taxPercent}%`}}/></div><p>尚有 {Math.max(0, taxTotalCustomers - taxCompletedCustomers)} 家未完成</p><button className="unreceived-alert" onClick={() => setShowUnreceived((value) => !value)}><span><strong>尚有 {unreceived.length} 家未收到資料</strong><small>未填登記日期</small></span>{showUnreceived ? <ChevronUp size={20}/> : <ChevronDown size={20}/>}</button><button className="portal-enter tax-enter" onClick={() => setWorkspaceMode("tax")}>查看詳細進度</button></article><article className="progress-module voucher-progress"><h3>切傳票追蹤</h3><div className="progress-numbers"><strong>{voucherCompletedCustomers} / {voucherTotalCustomers} 家</strong><span>已完成</span><i/><b>完成率 {voucherPercent}%</b></div><div className="progress-track" aria-label={`切傳票完成率 ${voucherPercent}%`}><span style={{width:`${voucherPercent}%`}}/></div><p>尚有 {Math.max(0, voucherTotalCustomers - voucherCompletedCustomers)} 家未完成</p><button className="portal-enter voucher-enter" onClick={() => setWorkspaceMode("voucher")}>查看詳細進度</button></article></div>{showUnreceived && <section className="portal-panel"><div className="portal-panel-head"><div><h3>未收到資料明細 <span>（{unreceived.length} 家）</span></h3></div><button onClick={() => setShowUnreceived(false)}>收合 <ChevronUp size={16}/></button></div><div className="portal-panel-tools"><label><Search size={16}/><input value={unreceivedSearch} onChange={(event) => setUnreceivedSearch(event.target.value)} placeholder="搜尋客編或客戶名稱"/>{unreceivedSearch && <button onClick={() => setUnreceivedSearch("")} aria-label="清除搜尋"><X size={14}/></button>}</label><button className="button secondary" onClick={exportUnreceived} disabled={!unreceived.length}><Download size={16}/>匯出 Excel</button></div><div className="portal-table-wrap"><table className="portal-table"><thead><tr><th>客編</th><th>客戶名稱</th><th>負責人</th><th>最後更新時間</th></tr></thead><tbody>{visibleUnreceived.length ? visibleUnreceived.map((item) => <tr key={item.id}><td className="code">{item.code}</td><td className="title-cell">{item.title}</td><td>{item.owner || "未指定"}</td><td>{new Date(item.updatedAt).toLocaleString("zh-TW")}</td></tr>) : <tr><td colSpan={4} className="portal-empty">沒有符合的客戶</td></tr>}</tbody></table></div></section>}<section className="portal-panel recent-panel"><button className="recent-toggle" onClick={() => setShowRecent((value) => !value)}><h3>近期更新 <span>（最近 5 筆）</span></h3><span>{showRecent ? "收合" : "展開"} {showRecent ? <ChevronUp size={16}/> : <ChevronDown size={16}/>}</span></button>{showRecent && <div className="recent-list">{recentUpdates.length ? recentUpdates.map((item) => <div className="recent-row" key={item.id}><span className={`recent-dot ${item.module === "營業稅" ? "tax-dot" : "voucher-dot"}`}/><strong>{item.code}</strong><span className="recent-title">{item.title}</span><span className={`module-badge ${item.module === "營業稅" ? "tax-badge" : "voucher-badge"}`}>{item.module}</span><span>{item.text}</span><span>{item.handler}</span><time>{formatRecentTime(item.updatedAt)}</time></div>) : <p className="portal-empty">目前尚無更新紀錄</p>}</div>}</section></section></main>;
  if (workspaceMode === "voucher") return <VoucherTracker onBack={() => setWorkspaceMode("portal")} onLogout={logout}/>;

  return <main>
    {toast && <div className="toast"><CircleCheck size={17} />{toast}</div>}
    {pendingRestore && <div className="modal-backdrop" onMouseDown={() => setPendingRestore(null)}><div className="modal small" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>從 JSON 備份還原</h3><p>備份檔包含 {pendingRestore.length} 家客戶。還原後會覆蓋目前全部資料，確定要繼續嗎？</p></div><button className="icon-button" onClick={() => setPendingRestore(null)}><X size={19}/></button></div><div className="modal-actions"><button className="button secondary" onClick={() => setPendingRestore(null)}>取消</button><button className="button primary" onClick={restoreBackup}>確認還原</button></div></div></div>}
    {showClearAll && <div className="modal-backdrop" onMouseDown={() => setShowClearAll(false)}><div className="modal small" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>確認清除嗎？</h3><p>將清除目前全部 {customers.length} 家客戶資料。此動作無法復原，請先確認已有備份。</p></div><button className="icon-button" onClick={() => setShowClearAll(false)}><X size={19}/></button></div><div className="modal-actions"><button className="button secondary" onClick={() => setShowClearAll(false)}>取消</button><button className="button destructive" onClick={clearAllCustomers}>確認清除</button></div></div></div>}
    <header className="topbar"><div className="brand"><div className="brand-mark"><FileSpreadsheet size={21} /></div><div><h1>發票進度追蹤</h1><p>營業稅申報進度管理</p></div></div>
      <div className="actions"><button className="button secondary" onClick={() => setWorkspaceMode("portal")}><ArrowLeft size={16}/>返回入口</button><input ref={fileInput} type="file" accept=".xlsx,.xls,.csv" hidden onChange={(event) => { const file = event.target.files?.[0]; if (file) importFile(file); event.target.value = ""; }} />
        <input ref={restoreInput} type="file" accept=".json,application/json" hidden onChange={(event) => { const file = event.target.files?.[0]; if (file) readBackupFile(file); event.target.value = ""; }} />
        <button className="button secondary" onClick={() => fileInput.current?.click()}><Upload size={16} />匯入 Excel</button>
        <button className="button secondary" onClick={() => restoreInput.current?.click()}><Upload size={16} />JSON 還原</button>
        <button className="button secondary" onClick={exportFile}><Download size={16} />匯出進度</button>
        <button className="button primary save-button" onClick={saveJson}><Save size={16} />儲存</button>
        <button className="button destructive" onClick={() => setShowClearAll(true)} disabled={!customers.length}><Trash2 size={16} />清除所有資料</button>
        <button className="button primary" onClick={() => { setForm({ code: "", title: "", owner: "", registeredDate: today() }); setShowAdd(true); }}><Plus size={16} />新增客戶</button>
        <button className="button secondary logout-button" onClick={logout}><LogOut size={16} />登出</button>
      </div></header>
      <section className="page-shell"><div className="welcome"><div><p className="eyebrow">本期申報進度</p><h2>客戶資料由你自行建立</h2><p>逐筆新增或匯入 Excel，所有同事都會看到最新進度。</p></div><div className="period"><span>共用狀態</span><strong>團隊資料已同步</strong></div></div>
      <section className="stats-grid" aria-label="進度統計">
        <div className="stats-row stats-row-four">
          <StatCard label="總客戶數" value={stats.total} tone="blue" icon={<Users size={20}/>} onClick={() => setDetailStage("總客戶數")} />
          <StatCard label="尚未登記" value={stats.undated} tone="red" icon={<CalendarDays size={20}/>} onClick={() => setDetailStage("尚未登記")} />
          <StatCard label="已登記數" value={stats.registered} tone="teal" icon={<CalendarDays size={20}/>} onClick={() => setDetailStage("已登記數")} />
          <StatCard label="已完成數" value={stats.done} tone="green" icon={<CircleCheck size={20}/>} onClick={() => setDetailStage("已完成數")} />
        </div>
        <div className="stats-row stats-row-four">
          <StatCard label="已整理" value={stats.sorted} tone="orange" icon={<FileSpreadsheet size={20}/>} onClick={() => setDetailStage("已整理")} />
          <StatCard label="已 Key in" value={stats.keyed} tone="purple" icon={<Clock3 size={20}/>} onClick={() => setDetailStage("已 Key in")} />
          <StatCard label="已檢查" value={stats.checked} tone="teal" icon={<Check size={20}/>} onClick={() => setDetailStage("已檢查")} />
          <StatCard label="已上傳" value={stats.uploaded} tone="sky" icon={<Upload size={20}/>} onClick={() => setDetailStage("已上傳")} />
        </div>
      </section>
      <section className="workspace"><div className="workspace-heading"><div><h3>客戶處理進度</h3><p>{customers.length ? (search || owner !== ALL_OWNERS || stageFilter !== ALL_STAGES || codeGroupFilter !== ALL_CODE_GROUPS ? `目前顯示 ${visible.length} 家（篩選後）／共 ${customers.length} 家` : `共 ${customers.length} 家`) : "尚未建立客戶"}</p></div><div className="legend"><span><i className="dot done"/>已完成</span><span><i className="dot waiting"/>尚未完成</span></div></div>
        <div className="filters"><label className="search-box"><Search size={17}/><input placeholder="搜尋客編；多家可用空格分開…" value={search} onChange={(event) => setSearch(event.target.value)}/>{search && <button type="button" className="search-clear" onClick={() => setSearch("")} aria-label="清除搜尋"><X size={15}/></button>}</label>
          <label className="select-box"><Filter size={16}/><select value={codeGroupFilter} onChange={(event) => setCodeGroupFilter(event.target.value)}><option>{ALL_CODE_GROUPS}</option>{CODE_GROUPS.map((group) => <option key={group}>{group}</option>)}</select><ChevronDown size={15}/></label>
          <label className="select-box"><Users size={16}/><select value={owner} onChange={(event) => setOwner(event.target.value)}><option>{ALL_OWNERS}</option>{owners.map((person) => <option key={person}>{person}</option>)}</select><ChevronDown size={15}/></label>
          <label className="select-box"><Filter size={16}/><select value={stageFilter} onChange={(event) => setStageFilter(event.target.value)}><option>{ALL_STAGES}</option><option>待整理</option><option>Key in 中</option><option>待檢查</option><option>待上傳</option><option>已完成</option></select><ChevronDown size={15}/></label>
          <button className="button batch-fixed" disabled={!selectedCustomers.length} onClick={() => setShowBatch(true)}><Check size={15}/>批次處理{selectedCustomers.length ? `（${selectedCustomers.length}）` : ""}</button></div>
        {!customers.length ? <div className="empty empty-start"><div className="empty-icon"><FileSpreadsheet size={25}/></div><strong>目前還沒有客戶資料</strong><p>按「新增客戶」自行輸入，或從 Excel 匯入。</p><button className="button primary" onClick={() => setShowAdd(true)}><Plus size={15}/>新增第一位客戶</button></div>
        : !visible.length ? <div className="empty"><strong>找不到符合條件的客戶</strong><p>請調整搜尋或篩選條件。</p><button className="button secondary" onClick={resetFilters}>清除篩選</button></div>
        : <div className="table-wrap"><table><thead><tr><th className="select-column"><input type="checkbox" checked={allVisibleSelected} onChange={toggleAllVisible} aria-label="選取目前顯示的全部客戶"/></th><th>客編</th><th>抬頭</th><th>負責人</th><th>登記日期</th><th>整理</th><th>Key in</th><th>檢查</th><th>上傳</th><th>目前階段</th><th>操作</th></tr></thead><tbody>{visible.map((item) => <tr key={item.id} className={selectedIds.has(item.id) ? "selected-row" : ""}><td className="select-column"><input type="checkbox" checked={selectedIds.has(item.id)} onChange={() => toggleSelected(item.id)} aria-label={`選取 ${item.title}`}/></td><td className="code">{item.code}</td><td className="title-cell">{item.title}</td><td><input className="inline-field owner-field" value={item.owner} placeholder="未填寫" onChange={(event) => updateCustomer(item.id, { owner: event.target.value })} aria-label={`${item.title}的負責人`}/></td><td><input className="inline-field date-field" type="date" value={item.registeredDate} onChange={(event) => updateCustomer(item.id, { registeredDate: event.target.value })} aria-label={`${item.title}的登記日期`}/></td>{(["sort", "keyin", "check", "upload"] as StepKey[]).map((key) => <td key={key}><StepButton step={item[key]} label={STEP_LABELS[key]} onClick={() => setEditingStep({ customer: item, key })}/></td>)}<td><span className={`stage stage-${stage(item).replaceAll(" ", "-")}`}>{stage(item)}</span></td><td><button className="icon-button danger" aria-label={`刪除 ${item.title}`} onClick={() => setDeleting(item)}><Trash2 size={16}/></button></td></tr>)}</tbody></table></div>}
      </section><div className="privacy-note"><Info size={15}/><span>資料已改為團隊共用；同事重新開啟或重新整理即可看到最新狀態。</span></div>
    </section>
    {showAdd && <div className="modal-backdrop" onMouseDown={() => setShowAdd(false)}><div className="modal" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>新增客戶</h3><p>建立一筆新的客戶進度資料</p></div><button className="icon-button" onClick={() => setShowAdd(false)}><X size={19}/></button></div><form onSubmit={addCustomer}><div className="form-grid"><label>客編<span>*</span><input value={form.code} onChange={(event) => setForm({...form, code:event.target.value})} required autoFocus/></label><label>抬頭<span>*</span><input value={form.title} onChange={(event) => setForm({...form, title:event.target.value})} required/></label><label>負責人<span>*</span><input value={form.owner} onChange={(event) => setForm({...form, owner:event.target.value})} required/></label><label>登記日期<span>*</span><input type="date" value={form.registeredDate} onChange={(event) => setForm({...form, registeredDate:event.target.value})} required/></label></div><div className="modal-actions"><button type="button" className="button secondary" onClick={() => setShowAdd(false)}>取消</button><button className="button primary">新增客戶</button></div></form></div></div>}
    {deleting && <div className="modal-backdrop" onMouseDown={() => setDeleting(null)}><div className="modal small" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>刪除客戶</h3><p>確定要刪除「{deleting.title}」嗎？此動作無法復原。</p></div></div><div className="modal-actions"><button className="button secondary" onClick={() => setDeleting(null)}>取消</button><button className="button destructive" onClick={async () => { const target = deleting; setCustomers((items) => items.filter((item) => item.id !== target.id)); setDeleting(null); await fetch("/api/customers", { method: "DELETE", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: target.id }) }); notify(`已刪除 ${target.title}`); }}>確認刪除</button></div></div></div>}
    {editingStep && <div className="modal-backdrop" onMouseDown={() => setEditingStep(null)}><div className="modal small" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>{STEP_LABELS[editingStep.key]}經手人</h3><p>請選擇這一步是誰做的；若要取消完成，請使用下方按鈕。</p></div><button className="icon-button" onClick={() => setEditingStep(null)}><X size={19}/></button></div><div className="handler-options">{HANDLERS.map((handler) => <button key={handler} className={`handler-option ${editingStep.customer[editingStep.key].handler === handler ? "selected" : ""}`} onClick={() => setStep(handler)}>{handler}</button>)}</div><div className="modal-actions"><button className="button secondary" onClick={() => setEditingStep(null)}>關閉</button>{editingStep.customer[editingStep.key].done && <button className="button destructive" onClick={() => setStep(null)}>取消完成</button>}</div></div></div>}
    {showBatch && <div className="modal-backdrop" onMouseDown={() => setShowBatch(false)}><div className="modal small" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>批次處理</h3><p>將設定套用到已選取的 {selectedCustomers.length} 家客戶。</p></div><button className="icon-button" onClick={() => setShowBatch(false)}><X size={19}/></button></div><div className="batch-form batch-selects"><label>工作項目<select value={batchItem} onChange={(event) => setBatchItem(event.target.value as StepKey | "date")}><option value="date">登記日期</option>{(["sort", "keyin", "check", "upload"] as StepKey[]).map((key) => <option key={key} value={key}>{STEP_LABELS[key]}</option>)}</select></label><label>設定狀態<select value={batchStatus} onChange={(event) => setBatchStatus(event.target.value as "done" | "cancel")}><option value="done">{batchItem === "date" ? "設定日期" : "完成"}</option><option value="cancel">{batchItem === "date" ? "取消登記" : "取消完成"}</option></select></label>{batchItem === "date" && batchStatus === "done" ? <label>登記日期<input type="date" value={batchDate} onChange={(event) => setBatchDate(event.target.value)}/></label> : batchItem !== "date" && batchStatus === "done" && <label>經手人<select value={batchHandler} onChange={(event) => setBatchHandler(event.target.value)}>{HANDLERS.map((handler) => <option key={handler}>{handler}</option>)}</select></label>}</div><div className="modal-actions"><button className="button secondary" onClick={() => setShowBatch(false)}>關閉</button><button className={batchStatus === "cancel" ? "button destructive" : "button primary"} disabled={batchSaving || (batchItem === "date" && batchStatus === "done" && !batchDate)} onClick={() => batchItem === "date" ? applyBulk((item) => ({ ...item, registeredDate: batchStatus === "done" ? batchDate : "" }), batchStatus === "done" ? `已批次設定登記日期：${selectedCustomers.length} 家` : `已批次取消登記：${selectedCustomers.length} 家`) : applyBulk((item) => ({ ...item, [batchItem]: batchStatus === "done" ? { done: true, handler: batchHandler } : { done: false, handler: null } }), batchStatus === "done" ? `已批次完成${STEP_LABELS[batchItem]}：${selectedCustomers.length} 家` : `已批次取消${STEP_LABELS[batchItem]}：${selectedCustomers.length} 家`)}>套用設定</button></div></div></div>}
    {detailStage && <div className="modal-backdrop" onMouseDown={() => setDetailStage(null)}><div className="modal detail-modal" onMouseDown={(event) => event.stopPropagation()}><div className="modal-head"><div><h3>{detailStage}明細</h3><p>共 {detailCustomers.length} 家客戶</p></div><button className="icon-button" onClick={() => setDetailStage(null)}><X size={19}/></button></div><div className="detail-list">{detailCustomers.length ? detailCustomers.map((item) => <div className="detail-row" key={item.id}><div><strong>{item.title}</strong><span>{item.code}</span></div><div><span>{item.owner || "未填負責人"}</span><span>{item.registeredDate ? displayDate(item.registeredDate) : "未填登記日期"}</span></div><span className={`stage stage-${stage(item).replaceAll(" ", "-")}`}>{stage(item)}</span></div>) : <div className="detail-empty">目前沒有此狀態的客戶</div>}</div><div className="modal-actions"><button className="button secondary" onClick={() => setDetailStage(null)}>關閉</button><button className="button primary" onClick={exportDetail} disabled={!detailCustomers.length}><Download size={15}/>匯出 Excel</button></div></div></div>}
  </main>;
}
