import { isAuthenticated, unauthorized } from "../../password-auth";

type Step = { done: boolean; handler: string | null };
type Customer = {
  id: string;
  code: string;
  title: string;
  owner: string;
  registeredDate: string;
  sort: Step;
  keyin: Step;
  check: Step;
  upload: Step;
  updatedAt: string;
};

async function database() {
  const { env } = await import("cloudflare:workers");
  return env.DB;
}

async function ready() {
  const db = await database();
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE COLLATE NOCASE,
      title TEXT NOT NULL,
      owner TEXT NOT NULL DEFAULT '',
      registered_date TEXT NOT NULL DEFAULT '',
      sort_done INTEGER NOT NULL DEFAULT 0,
      sort_handler TEXT,
      keyin_done INTEGER NOT NULL DEFAULT 0,
      keyin_handler TEXT,
      check_done INTEGER NOT NULL DEFAULT 0,
      check_handler TEXT,
      upload_done INTEGER NOT NULL DEFAULT 0,
      upload_handler TEXT,
      updated_at TEXT NOT NULL
    )`),
    db.prepare("CREATE INDEX IF NOT EXISTS customers_code_idx ON customers(code)"),
  ]);
  return db;
}

function shape(row: Record<string, unknown>): Customer {
  return {
    id: String(row.id),
    code: String(row.code),
    title: String(row.title),
    owner: String(row.owner ?? ""),
    registeredDate: String(row.registered_date ?? ""),
    sort: { done: Boolean(row.sort_done), handler: row.sort_handler ? String(row.sort_handler) : null },
    keyin: { done: Boolean(row.keyin_done), handler: row.keyin_handler ? String(row.keyin_handler) : null },
    check: { done: Boolean(row.check_done), handler: row.check_handler ? String(row.check_handler) : null },
    upload: { done: Boolean(row.upload_done), handler: row.upload_handler ? String(row.upload_handler) : null },
    updatedAt: String(row.updated_at),
  };
}

function statement(db: D1Database, customer: Customer) {
  return db.prepare(`INSERT INTO customers (
    id, code, title, owner, registered_date,
    sort_done, sort_handler, keyin_done, keyin_handler,
    check_done, check_handler, upload_done, upload_handler, updated_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(id) DO UPDATE SET
    code=excluded.code, title=excluded.title, owner=excluded.owner,
    registered_date=excluded.registered_date,
    sort_done=excluded.sort_done, sort_handler=excluded.sort_handler,
    keyin_done=excluded.keyin_done, keyin_handler=excluded.keyin_handler,
    check_done=excluded.check_done, check_handler=excluded.check_handler,
    upload_done=excluded.upload_done, upload_handler=excluded.upload_handler,
    updated_at=excluded.updated_at`).bind(
      customer.id, customer.code.trim(), customer.title.trim(), customer.owner ?? "", customer.registeredDate ?? "",
      customer.sort?.done ? 1 : 0, customer.sort?.handler ?? null,
      customer.keyin?.done ? 1 : 0, customer.keyin?.handler ?? null,
      customer.check?.done ? 1 : 0, customer.check?.handler ?? null,
      customer.upload?.done ? 1 : 0, customer.upload?.handler ?? null,
      customer.updatedAt || new Date().toISOString(),
    );
}

export async function GET(request: Request) {
  if (!(await isAuthenticated(request))) return unauthorized();
  const db = await ready();
  const result = await db.prepare("SELECT * FROM customers ORDER BY code COLLATE NOCASE").all();
  return Response.json(result.results.map((row) => shape(row as Record<string, unknown>)));
}

export async function POST(request: Request) {
  if (!(await isAuthenticated(request))) return unauthorized();
  const db = await ready();
  const customer = await request.json<Customer>();
  if (!customer.id || !customer.code?.trim() || !customer.title?.trim()) {
    return Response.json({ error: "missing id/code/title" }, { status: 400 });
  }
  try {
    await statement(db, customer).run();
    return Response.json({ ok: true });
  } catch {
    return Response.json({ error: "duplicate code" }, { status: 409 });
  }
}

export async function PUT(request: Request) {
  if (!(await isAuthenticated(request))) return unauthorized();
  const db = await ready();
  const customers = await request.json<Customer[]>();
  if (!Array.isArray(customers)) return Response.json({ error: "expected array" }, { status: 400 });
  const commands = [db.prepare("DELETE FROM customers"), ...customers.map((customer) => statement(db, customer))];
  await db.batch(commands);
  return Response.json({ ok: true, count: customers.length });
}

export async function DELETE(request: Request) {
  if (!(await isAuthenticated(request))) return unauthorized();
  const db = await ready();
  const body = await request.json<{ id?: string }>();
  if (!body.id) return Response.json({ error: "missing id" }, { status: 400 });
  await db.prepare("DELETE FROM customers WHERE id = ?").bind(body.id).run();
  return Response.json({ ok: true });
}
