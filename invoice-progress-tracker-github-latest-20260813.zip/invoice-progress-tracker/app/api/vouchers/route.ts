import { isAuthenticated, unauthorized } from "../../password-auth";

type Step = { done: boolean; handler: string | null };
type VoucherCustomer = {
  id: string; code: string; title: string; owner: string; registeredDate: string;
  inspect: Step; extra: Step; journal: Step; bind: Step; restore: Step; updatedAt: string;
};

async function database() {
  const { env } = await import("cloudflare:workers");
  return env.DB;
}

async function ready() {
  const db = await database();
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS voucher_customers (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE COLLATE NOCASE,
      title TEXT NOT NULL,
      owner TEXT NOT NULL DEFAULT '',
      registered_date TEXT NOT NULL DEFAULT '',
      inspect_done INTEGER NOT NULL DEFAULT 0,
      inspect_handler TEXT,
      extra_done INTEGER NOT NULL DEFAULT 0,
      extra_handler TEXT,
      journal_done INTEGER NOT NULL DEFAULT 0,
      journal_handler TEXT,
      bind_done INTEGER NOT NULL DEFAULT 0,
      bind_handler TEXT,
      restore_done INTEGER NOT NULL DEFAULT 0,
      restore_handler TEXT,
      updated_at TEXT NOT NULL
    )`),
    db.prepare("CREATE INDEX IF NOT EXISTS voucher_customers_code_idx ON voucher_customers(code)"),
  ]);
  return db;
}

function shape(row: Record<string, unknown>): VoucherCustomer {
  const step = (key: string): Step => ({ done: Boolean(row[`${key}_done`]), handler: row[`${key}_handler`] ? String(row[`${key}_handler`]) : null });
  return {
    id: String(row.id), code: String(row.code), title: String(row.title), owner: String(row.owner ?? ""),
    registeredDate: String(row.registered_date ?? ""), inspect: step("inspect"), extra: step("extra"),
    journal: step("journal"), bind: step("bind"), restore: step("restore"), updatedAt: String(row.updated_at),
  };
}

function statement(db: D1Database, item: VoucherCustomer) {
  return db.prepare(`INSERT INTO voucher_customers (
    id, code, title, owner, registered_date,
    inspect_done, inspect_handler, extra_done, extra_handler, journal_done, journal_handler,
    bind_done, bind_handler, restore_done, restore_handler, updated_at
  ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  ON CONFLICT(id) DO UPDATE SET
    code=excluded.code, title=excluded.title, owner=excluded.owner, registered_date=excluded.registered_date,
    inspect_done=excluded.inspect_done, inspect_handler=excluded.inspect_handler,
    extra_done=excluded.extra_done, extra_handler=excluded.extra_handler,
    journal_done=excluded.journal_done, journal_handler=excluded.journal_handler,
    bind_done=excluded.bind_done, bind_handler=excluded.bind_handler,
    restore_done=excluded.restore_done, restore_handler=excluded.restore_handler,
    updated_at=excluded.updated_at`).bind(
      item.id, item.code.trim(), item.title.trim(), item.owner ?? "", item.registeredDate ?? "",
      item.inspect?.done ? 1 : 0, item.inspect?.handler ?? null,
      item.extra?.done ? 1 : 0, item.extra?.handler ?? null,
      item.journal?.done ? 1 : 0, item.journal?.handler ?? null,
      item.bind?.done ? 1 : 0, item.bind?.handler ?? null,
      item.restore?.done ? 1 : 0, item.restore?.handler ?? null,
      item.updatedAt || new Date().toISOString(),
    );
}

export async function GET(request: Request) {
  if (!(await isAuthenticated(request))) return unauthorized();
  const db = await ready();
  const result = await db.prepare("SELECT * FROM voucher_customers ORDER BY code COLLATE NOCASE").all();
  return Response.json(result.results.map((row) => shape(row as Record<string, unknown>)));
}

export async function POST(request: Request) {
  if (!(await isAuthenticated(request))) return unauthorized();
  const db = await ready();
  const item = await request.json<VoucherCustomer>();
  if (!item.id || !item.code?.trim() || !item.title?.trim()) return Response.json({ error: "missing id/code/title" }, { status: 400 });
  try { await statement(db, item).run(); return Response.json({ ok: true }); }
  catch { return Response.json({ error: "duplicate code" }, { status: 409 }); }
}

export async function PUT(request: Request) {
  if (!(await isAuthenticated(request))) return unauthorized();
  const db = await ready();
  const items = await request.json<VoucherCustomer[]>();
  if (!Array.isArray(items)) return Response.json({ error: "expected array" }, { status: 400 });
  await db.batch([db.prepare("DELETE FROM voucher_customers"), ...items.map((item) => statement(db, item))]);
  return Response.json({ ok: true, count: items.length });
}

export async function DELETE(request: Request) {
  if (!(await isAuthenticated(request))) return unauthorized();
  const db = await ready();
  const body = await request.json<{ id?: string }>();
  if (!body.id) return Response.json({ error: "missing id" }, { status: 400 });
  await db.prepare("DELETE FROM voucher_customers WHERE id = ?").bind(body.id).run();
  return Response.json({ ok: true });
}
