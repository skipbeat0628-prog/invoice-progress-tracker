import { deleteSession } from "../../../password-auth";

export async function POST(request: Request) {
  return new Response(JSON.stringify({ ok: true }), {
    headers: { "Content-Type": "application/json", "Set-Cookie": await deleteSession(request) },
  });
}
