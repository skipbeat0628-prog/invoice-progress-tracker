import { createSession, verifyPassword } from "../../../password-auth";

export async function POST(request: Request) {
  const body = await request.json<{ password?: string }>().catch(() => ({}));
  if (!body.password || !(await verifyPassword(body.password))) {
    return Response.json({ error: "密碼錯誤" }, { status: 401 });
  }
  const session = await createSession();
  return new Response(JSON.stringify({ ok: true }), {
    headers: { "Content-Type": "application/json", "Set-Cookie": session.cookie },
  });
}
