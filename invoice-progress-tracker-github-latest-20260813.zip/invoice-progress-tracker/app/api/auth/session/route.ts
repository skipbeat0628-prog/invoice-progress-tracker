import { isAuthenticated } from "../../../password-auth";

export async function GET(request: Request) {
  return Response.json({ authenticated: await isAuthenticated(request) });
}
