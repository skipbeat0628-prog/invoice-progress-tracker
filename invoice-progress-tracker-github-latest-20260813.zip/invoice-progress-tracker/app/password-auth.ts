const COOKIE_NAME = "invoice_session";
const SESSION_DAYS = 7;

async function database() {
  const { env } = await import("cloudflare:workers");
  return env.DB;
}

async function configuredPasswordHash() {
  const { env } = await import("cloudflare:workers");
  const value = String((env as Record<string, unknown>).APP_PASSWORD_HASH || "");
  if (!value) throw new Error("APP_PASSWORD_HASH is not configured");
  return value;
}

async function digest(value: string) {
  const bytes = new TextEncoder().encode(value);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

function sameValue(left: string, right: string) {
  if (left.length !== right.length) return false;
  let result = 0;
  for (let index = 0; index < left.length; index++) result |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return result === 0;
}

async function ready() {
  const db = await database();
  await db.prepare(`CREATE TABLE IF NOT EXISTS login_sessions (
    token_hash TEXT PRIMARY KEY,
    expires_at TEXT NOT NULL
  )`).run();
  return db;
}

function cookieValue(request: Request) {
  const source = request.headers.get("cookie") || "";
  for (const item of source.split(";")) {
    const [name, ...parts] = item.trim().split("=");
    if (name === COOKIE_NAME) return decodeURIComponent(parts.join("="));
  }
  return "";
}

export async function verifyPassword(password: string) {
  return sameValue(await digest(password), await configuredPasswordHash());
}

export async function createSession() {
  const tokenBytes = crypto.getRandomValues(new Uint8Array(32));
  const token = Array.from(tokenBytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400000);
  const db = await ready();
  await db.batch([
    db.prepare("DELETE FROM login_sessions WHERE expires_at <= ?").bind(new Date().toISOString()),
    db.prepare("INSERT INTO login_sessions (token_hash, expires_at) VALUES (?, ?)").bind(await digest(token), expiresAt.toISOString()),
  ]);
  return {
    token,
    cookie: `${COOKIE_NAME}=${encodeURIComponent(token)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_DAYS * 86400}`,
  };
}

export async function isAuthenticated(request: Request) {
  const token = cookieValue(request);
  if (!token) return false;
  const db = await ready();
  const row = await db.prepare("SELECT expires_at FROM login_sessions WHERE token_hash = ?").bind(await digest(token)).first<{ expires_at: string }>();
  if (!row || row.expires_at <= new Date().toISOString()) return false;
  return true;
}

export async function deleteSession(request: Request) {
  const token = cookieValue(request);
  if (token) {
    const db = await ready();
    await db.prepare("DELETE FROM login_sessions WHERE token_hash = ?").bind(await digest(token)).run();
  }
  return `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

export function unauthorized() {
  return Response.json({ error: "unauthorized" }, { status: 401 });
}
